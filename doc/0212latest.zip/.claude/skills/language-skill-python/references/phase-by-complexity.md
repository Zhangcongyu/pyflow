# Phase 0-2 按复杂度差异化

本文档详细说明 Phase 0-2 在不同复杂度下的执行差异。

---

## Phase 0: 需求分析

### 执行条件

| 复杂度 | 新项目 | 老项目新增功能 |
|--------|--------|---------------|
| **简单** | 可选（需求明确时跳过） | 跳过 |
| **中等** | 推荐 | 推荐 |
| **复杂** | ⭐ **必需** | ⭐ **必需** |

### 详细说明

#### 简单项目 - 可选/跳过

**何时跳过**:
- 需求非常明确（如"创建一个简单的加法器"）
- 单一功能，无歧义
- 用户直接给出具体实现要求

**何时执行**:
- 需求有模糊之处
- 不确定最佳实现方式
- 需要讨论技术选型

#### 中等项目 - 推荐

**何时执行**:
- 需要明确功能范围
- 需要讨论架构设计
- 需要确定技术选型

**不执行的情况**:
- 用户提供了详细的需求文档
- 需求已经非常明确

#### 复杂项目 - ⭐ 必需

**必须执行**:
- 多模块系统，需要明确模块边界
- 需要详细架构设计
- 需要性能、安全等非功能性需求
- 需要确定技术栈和依赖

### 使用工具

**工具**: `superpowers:brainstorming`

**传入参数**:
- 项目类型提示（新项目 / 老项目新增功能）
- 用户原始需求
- 复杂度提示（简单 / 中等 / 复杂）

**输出**: `docs/plans/YYYY-MM-DD-<feature-name>-design.md`

**验证**: 设计文档已生成

---

## Phase 1: 项目规则

### 新项目模式

#### 简单项目 - 精简 constitution

**执行方式**: 精简

**内容**:
- 基础编码规范（类型注解）
- 基础测试要求（pytest）
- 基础代码检查（ruff）

**不包含**:
- 详细的架构原则
- ADR 记录
- 复杂的质量标准

#### 中等项目 - 完整 constitution

**执行方式**: 完整

**内容**:
- 完整编码规范
- 测试要求（pytest, 覆盖率）
- 代码检查（ruff, mypy）
- 质量标准
- 项目结构规范

#### 复杂项目 - 完整+ADR

**执行方式**: 完整 + ADR

**内容**:
- 完整 constitution（同中等项目）
- ADR（Architecture Decision Records）模板
- 技术选型记录
- 设计原则

### 老项目新增功能模式

#### 简单项目 - 跳过

**不执行 Phase 1**

**原因**: 简单功能不需要修改项目规则

#### 中等项目 - 检查

**执行方式**: 检查

**目的**: 确认新功能不违反现有规则

**检查项**:
- 新功能是否需要新增编码规范？
- 新功能是否需要新的测试要求？
- 新功能是否与现有架构兼容？

**结果**:
- 如果兼容：跳过（不修改 constitution）
- 如果不兼容：进入"检查+更新"流程

#### 复杂项目 - 检查+更新

**执行方式**: 检查 + 更新

**目的**: 更新 constitution 以支持新功能

**更新内容**:
- 新增编码规范（如果需要）
- 新增测试要求（如果需要）
- 更新架构原则（如果需要）
- 添加 ADR 记录（如果需要）

### 使用工具

**步骤 1**: 调用 `scripts/init_constitution.py` 创建模板（新项目必需）

**步骤 2**: 调用 `speckit.constitution`

**新项目传入**:
- 项目名称
- 项目类型（python）
- Constitution 内容
- 复杂度（简单/中等/复杂）

**老项目传入**:
- 现有 constitution.md 路径
- 新功能描述
- 复杂度（中等/复杂）

**输出**: `.specify/memory/constitution.md`

**验证**: constitution.md 已创建/更新

---

## Phase 2: 项目准备

### 新项目模式

#### 简单项目 - 精简脚手架

**执行方式**: 精简

**项目结构**:
```
project-name/
├── src/
│   └── __init__.py
├── tests/
│   ├── __init__.py
│   └── test_main.py
├── pyproject.toml
└── README.md
```

**特点**:
- 最小化结构
- 仅包含基础目录
- 无分层架构

#### 中等项目 - 完整脚手架

**执行方式**: 完整

**项目结构**:
```
project-name/
├── src/
│   └── project_name/
│       ├── __init__.py
│       ├── main.py
│       ├── api/
│       │   ├── __init__.py
│       │   └── endpoints/
│       ├── services/
│       │   ├── __init__.py
│       │   └── service.py
│       ├── repositories/
│       │   ├── __init__.py
│       │   └── repository.py
│       ├── models/
│       │   ├── __init__.py
│       │   └── model.py
│       └── schemas/
│           ├── __init__.py
│           └── schema.py
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── test_api/
│   ├── test_services/
│   └── test_repositories/
├── pyproject.toml
└── README.md
```

**特点**:
- 分层架构（api/services/repositories）
- 完整测试结构
- 包含 models 和 schemas

#### 复杂项目 - 完整脚手架 + 多模块

**执行方式**: 完整 + 多模块

**项目结构**:
```
project-name/
├── src/
│   └── project_name/
│       ├── __init__.py
│       ├── main.py
│       ├── api/
│       │   ├── v1/
│       │   │   ├── __init__.py
│       │   │   └── endpoints/
│       │   └── v2/
│       │       ├── __init__.py
│       │       └── endpoints/
│       ├── core/
│       │   ├── __init__.py
│       │   ├── config.py
│       │   ├── security.py
│       │   └── exceptions.py
│       ├── services/
│       │   ├── __init__.py
│       │   ├── service_a.py
│       │   └── service_b.py
│       ├── repositories/
│       │   ├── __init__.py
│       │   └── repository.py
│       ├── models/
│       │   ├── __init__.py
│       │   ├── model_a.py
│       │   └── model_b.py
│       ├── schemas/
│       │   ├── __init__.py
│       │   └── schema.py
│       ├── utils/
│       │   ├── __init__.py
│       │   └── helpers.py
│       └── tasks/
│           ├── __init__.py
│           └── background_tasks.py
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── unit/
│   ├── integration/
│   └── e2e/
├── scripts/
├── docs/
│   └── adr/
├── pyproject.toml
└── README.md
```

**特点**:
- 多版本 API（v1, v2）
- 核心模块（core）
- 工具类（utils）
- 后台任务（tasks）
- 完整文档结构（docs/adr/）
- 脚本目录（scripts/）

### 老项目新增功能模式

#### 简单项目 - 基础验证

**验证命令**:
```bash
# 1. 验证虚拟环境
test -d .venv || echo "虚拟环境缺失"

# 2. 验证可导入
python -c "from <project> import __version__" || echo "导入失败"
```

**不执行**: 任何创建操作

#### 中等项目 - 标准验证 + 依赖

**验证命令**:
```bash
# 1. 验证虚拟环境
test -d .venv

# 2. 验证项目结构
ls -d src/<project>/{models,api,services,repositories,schemas}
```

**依赖检查**:
- 读取 Phase 0 设计文档
- 判断新功能是否需要新包
- 如需要：调用 `python-development:uv-package-manager`

**添加依赖示例**:
```bash
# 添加新依赖
uv add httpx aiofiles
```

#### 复杂项目 - 深度验证 + 依赖

**验证命令**:
```bash
# 1. 验证虚拟环境
test -d .venv

# 2. 验证项目结构
ls -d src/<project>/{models,api,services,repositories,schemas,utils,tasks}

# 3. 验证依赖完整性
uv pip check

# 4. 验证可导入
python -c "from <project> import __version__; from <project>.core import config"
```

**依赖检查**:
- 详细分析新功能需求
- 识别所有需要的依赖
- 调用 `python-development:uv-package-manager` 批量添加

### Git 状态说明

#### 新项目 - Git 已由 python-scaffold 初始化

**重要**: `python-development:python-scaffold` 已执行 `git init`

**验证**:
```bash
git status
# 应该看到: On branch main/master (或未提交的初始状态)
```

**Git 策略**: 新项目直接在主支（main/master）开发，无需创建分支

#### 老项目新增功能 - 创建 Worktree

**使用工具**: `superpowers:using-git-worktrees`

**目的**: 为新功能创建隔离的 worktree

**传入**:
- 功能描述
- 项目路径
- 分支命名建议: `feature-{feature-name}`

**输出**: `.worktrees/feature-{feature-name}/`

**验证**:
```bash
git worktree list
cd .worktrees/feature-{feature-name}
```

**重要**: 后续所有 Phase 3-5 都在 worktree 中执行

---

## 总结对比表

| Phase | 简单 | 中等 | 复杂 |
|-------|------|------|------|
| **Phase 0** | 跳过 | 推荐 | ⭐ 必需 |
| **Phase 1 新** | 精简 | 完整 | 完整+ADR |
| **Phase 1 老** | 跳过 | 检查 | 检查+更新 |
| **Phase 2 新** | 精简脚手架（含 git init） | 完整脚手架（含 git init） | 完整脚手架+多模块（含 git init） |
| **Phase 2 老** | 基础验证 | 验证+依赖 | 深度验证+依赖 |
| **Phase 2 Git 新** | 已由 python-scaffold 初始化 | 已由 python-scaffold 初始化 | 已由 python-scaffold 初始化 |
| **Phase 2 Git 老** | 创建 worktree | 创建 worktree | 创建 worktree |

---

**文档创建时间**: 2026-02-10
**更新时间**: 2026-02-10
**用途**: Phase 0-2 按复杂度差异化说明
**说明**: 已删除 Phase 3（planning-with-files 工具已废弃）
