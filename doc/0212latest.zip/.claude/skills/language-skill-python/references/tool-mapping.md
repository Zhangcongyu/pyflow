# 工具映射表

本文档提供完整的工具映射表，说明在每个 Phase、项目状态、复杂度下应该调用哪个工具。

---

## 完整工具映射表

| Phase | 新/老 | 复杂度 | 工具类型 | 工具名称 | 用途 |
|-------|------|--------|---------|---------|------|
| Phase 0 | 所有 | 中等/复杂 | Skill | `superpowers:brainstorming` | 需求分析 |
| Phase 1 | 新 | 所有 | Skill | `speckit.constitution` | 制定规则 |
| Phase 1 | 老 | 中等/复杂 | Skill | `speckit.constitution` | 检查规则 |
| Phase 2.1 | 新 | 所有 | Skill | `python-development:python-scaffold` | 创建脚手架 |
| Phase 2.2 | 新 | 所有 | Skill | `superpowers:using-git-worktrees` | 创建分支 |
| Phase 2.1 | 老 | 简单 | Bash | (验证命令) | 验证环境 |
| Phase 2.2 | 老 | 中等/复杂 | Skill | `python-development:uv-package-manager` | 添加依赖 |
| Phase 2.3 | 老 | 所有 | Skill | `superpowers:using-git-worktrees` | 创建 worktree |
| Phase 3 | 所有 | 中等/复杂 | Skill | `planning-with-files` | 制定计划 |
| Phase 4 简单 | 所有 | 简单 | Skill | `tdd-cycle` | TDD 完整流程 |
| Phase 4 RED | 所有 | 中等/复杂 | Task | `unit-testing:test-automator` | 生成测试 |
| Phase 4 GREEN | 所有 | 中等 | Task | `python-development:python-pro` | 实现功能 |
| Phase 4 GREEN | 所有 | 复杂 | Task + Skill | `python-pro` + `async-python-patterns` | 实现+优化 |
| Phase 4 REFACTOR | 所有 | 中等 | Task | `python-development:python-pro` | 重构 |
| Phase 4 REFACTOR | 所有 | 复杂 | Task + Skill | `performance-opt` + `python-pro` | 性能优化+重构 |
| Phase 5.1 | 所有 | 简单 | Bash | pytest + ruff | 基础验证 |
| Phase 5.1 | 所有 | 中等/复杂 | Bash | pytest + mypy + ruff | 完整验证 |
| Phase 5.2 | 所有 | 中等 | Task | `comprehensive-review:code-reviewer` | 代码审核 |
| Phase 5.2 | 所有 | 复杂 | Task + Task | `code-reviewer` + `security-auditor` | 完整审核 |
| Phase 5.3 | 所有 | 所有 | Skill | `superpowers:finishing-a-development-branch` | Git 完成 |

---

## 按使用场景分类

### 需求分析工具

| 工具 | 类型 | 使用场景 |
|------|------|---------|
| `superpowers:brainstorming` | Skill | 中等/复杂项目需求分析 |

### 项目规则工具

| 工具 | 类型 | 使用场景 |
|------|------|---------|
| `speckit.constitution` | Skill | 新项目制定规则 |
| `speckit.constitution` | Skill | 老项目检查/更新规则 |

### 项目准备工具

| 工具 | 类型 | 使用场景 |
|------|------|---------|
| `python-development:python-scaffold` | Skill | 新项目创建脚手架 |
| `python-development:uv-package-manager` | Skill | 老项目添加依赖 |
| `superpowers:using-git-worktrees` | Skill | 创建分支/worktree |

### 实施计划工具

| 工具 | 类型 | 使用场景 |
|------|------|---------|
| `planning-with-files` | Skill | 中等/复杂项目制定计划 |

### TDD 工具

| 工具 | 类型 | 使用场景 | Phase |
|------|------|---------|-------|
| `tdd-cycle` | Skill | 简单项目 TDD | RED+GREEN+REFACTOR |
| `unit-testing:test-automator` | Task | 中等/复杂项目 RED | RED |
| `python-development:python-pro` | Task | 中等/复杂项目 GREEN/REFACTOR | GREEN+REFACTOR |
| `python-development:async-python-patterns` | Skill | 复杂项目异步优化 | GREEN |
| `python-development:python-performance-optimization` | Skill | 复杂项目性能优化 | GREEN+REFACTOR |

### 质量审核工具

| 工具 | 类型 | 使用场景 |
|------|------|---------|
| `comprehensive-review:code-reviewer` | Task | 中等项目代码审核 |
| `comprehensive-review:security-auditor` | Task | 复杂项目安全审核 |
| Bash (pytest) | Bash | 所有项目测试验证 |
| Bash (mypy) | Bash | 中等及以上项目类型检查 |
| Bash (ruff) | Bash | 所有项目代码检查 |

### Git 管理工具

| 工具 | 类型 | 使用场景 |
|------|------|---------|
| `superpowers:finishing-a-development-branch` | Skill | Git 分支完成 |

---

## 工具调用格式参考

### Skill 工具调用

```
Skill(
    skill="<tool-name>",
    args="<parameters>"
)
```

### Task 工具调用

```
Task(
    subagent_type="<plugin-name>:<agent-name>",
    subject="<简短标题>",
    description="<详细描述>",
    prompt="<完整上下文>",
    activeForm="<进行时态>"
)
```

---

## 特殊工具组合

### 简单项目快速路径

```
tdd-cycle (完整 TDD)
```

### 中等项目标准路径

```
Phase 4 分开执行:
1. unit-testing:test-automator (RED)
2. python-development:python-pro (GREEN)
3. python-development:python-pro (REFACTOR)
```

### 复杂项目完整路径

```
Phase 4 多步执行:
1. unit-testing:test-automator (RED)
2. python-development:python-pro (基础实现)
3. python-development:async-python-patterns (异步优化)
4. python-development:python-performance-optimization (性能优化)
5. python-development:python-performance-optimization (性能优化)
6. python-development:python-pro (最终清理)
```

---

## 工具版本和配置要求

### Python 版本

| 工具 | Python 版本要求 |
|------|----------------|
| 所有 Python 工具 | >= 3.11 |
| SQLAlchemy | 2.0+ |
| FastAPI | 0.100+ |
| Pydantic | 2.0+ |

### 依赖管理

| 工具 | 包管理器 | 镜像源（中国） |
|------|---------|----------------|
| 所有 Python 工具 | uv | 清华/华为云（自动检测） |

### 代码质量工具

| 工具 | 版本 | 用途 |
|------|------|------|
| pytest | 8.0+ | 测试 |
| ruff | latest | 代码检查 |
| mypy | 1.0+ | 类型检查 |

---

## 工具替代方案

### 如果工具不可用

| 原工具 | 替代方案 |
|--------|---------|
| `unit-testing:test-automator` | 手动编写测试（不推荐） |
| `python-development:python-pro` | 手动实现（不推荐） |
| `python-development:async-python-patterns` | 手动优化异步（不推荐） |
| `python-development:python-performance-optimization` | 手动性能优化（不推荐） |

### 替代方案使用条件

- 工具调用失败
- 工具不支持特定功能
- 需要特殊定制

---

## 工具调用顺序约束

### 必须遵守的顺序

1. **Phase 0 → Phase 1 → Phase 2 → Phase 3 → Phase 4 → Phase 5**
   - 严格按照顺序执行
   - 不可跳过必需的 Phase

2. **Phase 4 内部顺序**:
   - 简单: RED → GREEN → REFACTOR
   - 中等/复杂: RED → GREEN → REFACTOR
   - 复杂 GREEN: 基础实现 → 异步优化 → 性能优化
   - 复杂 REFACTOR: 性能优化 → 最终清理

3. **验证要求**:
   - 每个 Phase 完成后必须验证
   - 验证通过后才进入下一 Phase

### 可以并行的场景

- **不同模块的 Phase 4**: 如果有多个独立功能，可以并行执行

---

**文档创建时间**: 2026-02-09
**用途**: 完整工具映射表
