# 项目脚手架创建指南

**用途**: Phase 2 项目准备的详细执行指南

---

## 🎯 核心逻辑

1. **检查项目架构是否存在**
2. **如果不存在** → 按照项目类型创建完整脚手架
3. **如果已存在** → 检查并补齐缺失部分

---

## 📋 输入和参考

### 必须使用的结果

**Phase 0: 需求分析**（设计文档）
- 项目类型（FastAPI/Django/CLI/Library 等）
- 目录结构（如果定义了）
- 技术约束（Python 版本、依赖版本等）
- 功能需求

**Phase 1: 项目规则**（Constitution）
- 项目特定的编码标准
- 命名约定
- 架构原则
- 技术选型约束

### 参考文档

**project-archetypes.md**
- 使用条件：当 Phase 0 **没有定义目录结构**时
- 内容：对应项目类型的完整脚手架模板
- 包括：目录结构、pyproject.toml 模板、系统文件模板

---

## 📁 新项目：创建脚手架

### 决策逻辑

**目录结构来源**（优先级）:
1. ✅ **Phase 0 设计文档**中的目录结构（如果定义了）
2. ✅ **project-archetypes.md** 中对应项目类型的模板（如果 Phase 0 没有定义）

**系统文件内容来源**（优先级）:
1. ✅ **Phase 0 技术约束** - Python 版本、依赖版本、功能需求
2. ✅ **Phase 1 Constitution** - 编码标准、架构原则、命名约定
3. ✅ **project-archetypes.md** 模板 - 基础结构和配置

### 执行步骤

#### 步骤 1: 确定目录结构

```
IF Phase 0 设计文档包含目录结构:
    使用 Phase 0 定义的目录结构
ELSE:
    使用 project-archetypes.md 中对应项目类型的默认结构
END IF
```

#### 步骤 2: 创建目录和空文件

根据确定的目录结构：
- 创建所有目录
- 创建所有 `__init__.py` 文件（空）
- 创建编码文件（空文件，不编码）

#### 步骤 3: 编写系统文件

结合以下输入编写 `pyproject.toml`:
- **Phase 0 技术约束**: Python 版本、依赖版本、功能需求
- **Phase 1 Constitution**: 项目特定的技术要求和约束
- **project-archetypes.md**: 基础模板（包括 uv 镜像配置）

编写其他系统文件:
- `.gitignore` - Python 通用配置 + Phase 1 特定规则
- `Makefile` - 常用命令
- `README.md` - 项目说明（基于 Phase 0 需求）
- `.env.example` - 环境变量示例

#### 步骤 4: 创建虚拟环境并安装依赖

调用 `python-development:uv-package-manager`:
- 创建虚拟环境
- 根据 `pyproject.toml` 安装依赖

#### 步骤 5: 初始化 Git

```bash
git init
git add .
git commit -m "feat: initialize project scaffold"
```

#### 步骤 6: 验证脚手架

```bash
# 检查目录结构
tree -L 3

# 检查依赖安装
source .venv/bin/activate && pip list

# 检查 Git
git status

# 验证符合 Phase 0 设计
# - 目录结构匹配
# - 技术约束满足
# - Constitution 规则遵循
```

### 示例：电商 API 项目

**Phase 0 输入**（设计文档）:
- 项目类型: FastAPI
- 目录结构: 已定义 `src/ecommerce_api/` 结构
- 技术约束: Python >= 3.12, FastAPI >= 0.110.0, Pydantic >= 2.6.0

**Phase 1 输入**（Constitution）:
- Principle 5: Data Model Constraints（UUID v4, in-memory storage）
- 编码标准: 类型注解完整，mypy --strict

**执行结果**:
1. 目录结构：使用 Phase 0 定义的 `src/ecommerce_api/` 结构
2. pyproject.toml：结合 Phase 0 技术约束 + Phase 1 Principle 5
3. 系统文件：符合 Phase 1 编码标准

---

## 📁 老项目：检查并补齐

### 检查清单

```bash
# 检查虚拟环境
test -d .venv || echo "❌ 虚拟环境缺失"

# 检查镜像配置
grep -E "tool\.uv" pyproject.toml || echo "❌ 缺少 uv 镜像配置"

# 检查项目结构
test -d src || echo "❌ src 目录缺失"

# 检查 Constitution
test -f .specify/memory/constitution.md || echo "❌ Constitution 缺失"
```

### 补齐缺失部分

1. **缺失目录** → 参考 Phase 0 设计或 `project-archetypes.md` 创建
2. **缺失系统文件** → 结合 Phase 0/Phase 1 要求和模板编写
3. **缺失依赖** → 调用 `uv-package-manager` 安装
4. **缺失镜像配置** → 添加到 `pyproject.toml`
5. **缺失 Constitution** → 调用 `speckit.constitution` 创建

---

## 🌏 中国国内环境

### 检测

```bash
timeout 3 curl -s https://pypi.org >/dev/null 2>&1 && echo "international" || echo "china"
```

### 配置

**pyproject.toml**:
```toml
[[tool.uv.index]]
name = "tsinghua"
url = "https://pypi.tuna.tsinghua.edu.cn/simple"
default = true
```

---

## 📝 初始化 Checklist 追踪

### Checklist 的作用

- 追踪所有阶段的完成状态
- 记录每个阶段的验证结果
- 提供用户最终检查点

### 创建 CHECKLIST.md

在 Phase 2 完成脚手架后，从模板复制：

```bash
# 从模板复制
cp references/checklist-template.md CHECKLIST.md
```

### Skill 的职责

1. ✅ 在 Phase 2 创建 CHECKLIST.md（从模板复制）
2. ✅ 每完成一个阶段，自动标注完成状态
3. ✅ 记录验证结果到"Verification Results"代码块
4. ✅ 在 Phase 5 提交到 Git

### 用户的职责

1. 📖 查看 CHECKLIST.md 了解进度
2. ✅ 在 Phase 5 完成后进行最终检查
3. ✅ 签署验收

### Checklist 模板位置

`references/checklist-template.md`

**模板内容**：
- Phase 0: 需求分析 checklist
- Phase 1: 项目规则 checklist
- Phase 2: 项目准备 checklist
- Phase 4: TDD 执行 checklist (RED → GREEN → REFACTOR)
- Phase 5: 质量审核 checklist
- User Final Review: 用户签署验收

---

**文档创建时间**: 2026-02-10
**用途**: Phase 2 项目准备详细指南
