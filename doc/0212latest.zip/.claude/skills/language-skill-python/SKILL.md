---
name: language-skill-python
description: |
  Python 项目 TDD 开发编排器，根据三维参数（项目状态 + 复杂度 + 语言）选择对应流程。

  **触发条件**:
  - 由 project-orchestrator 路由调用（传递 --new/--add-feature + --simple/--medium/--complex）
  - 或直接请求 Python 项目开发

  **支持的三维组合** (6 种):
  1. --new --simple         (新-简单)
  2. --new --medium         (新-中等)
  3. --new --complex        (新-复杂)
  4. --add-feature --simple (老-简单)
  5. --add-feature --medium (老-中等)
  6. --add-feature --complex(老-复杂)

  **核心原则**: 编排器，负责调用工具链
  - ✅ 编排调用 Python 工具链
  - ✅ 根据新/老项目选择不同流程
  - ✅ **可以**创建脚手架（基础设施配置）
  - ❌ 不编写业务逻辑代码
---

# Python 项目 TDD 开发编排器

## 🎯 核心原则

**你是编排者（ORCHESTRATOR）**：
- ✅ **可以**创建脚手架（项目基础设施配置）
- ❌ **禁止**编写业务逻辑代码（必须使用 TDD 工具链）

**判断标准**：参考 [orchestration-rules.md](references/orchestration-rules.md)

**快速检查**：
- 这是脚手架吗？（所有项目都需要） → 使用 Write 工具 ✅
- 这是业务逻辑吗？（包含具体功能） → 使用 TDD 工具 ❌

---

## 编排者行为准则

**四步执行流程**：
1. **调用 tool/skill/agent** → 使用 Skill/Task/Bash 工具
2. **等待完成** ⏸️ → 暂停所有操作，等待 tool 返回
3. **验证结果** ✓ → 检查输出是否符合预期
4. **记录状态** 📝 → 更新状态，继续下一阶段

**🚨 绝对禁止**:
- ❌ 在 tool 执行期间自己写代码
- ❌ 在 tool 执行期间自己创建文件
- ❌ 认为"tool 太慢，我来帮忙"
- ❌ 跳过等待直接进入下一阶段

**💡 关键认知**: 你是**指挥官**，不是**士兵**。你的工作是决定"**谁来做**"，不是"**怎么做的**"。

---

## 📋 CHECKLIST.md 自动更新要求 ⭐ NEW

**在每个 Phase 完成后，必须更新 CHECKLIST.md 对应的 checkbox！**

### 更新时机

| Phase | 更新时机 | 更新内容 |
|-------|---------|---------|
| **Phase 0** | brainstorming 完成后 | 需求分析相关 checkbox |
| **Phase 1** | constitution 创建后 | 项目规则相关 checkbox |
| **Phase 2** | 脚手架创建后 | 项目准备相关 checkbox |
| **Phase 4.1** | RED Phase 完成后 | TDD-RED 相关 checkbox |
| **Phase 4.2** | GREEN Phase 完成后 | TDD-GREEN 相关 checkbox |
| **Phase 4.3** | REFACTOR Phase 完成后 | TDD-REFACTOR 相关 checkbox |
| **Phase 5** | 质量审核完成后 | 质量审核和 Git 相关 checkbox |

### 更新方法

使用 **Edit 工具** 将 `[ ]` 替换为 `[x]`，并添加验证结果：

```python
# 示例：Phase 1 完成后
Edit(
    file_path="CHECKLIST.md",
    old_string="- [ ] Constitution created/updated\n- [ ] Project-specific rules defined",
    new_string="- [x] Constitution created/updated\n- [x] Project-specific rules defined"
)
```

### 验证 CHECKLIST 已更新

```bash
# 确认至少有一个 [x] 标记
grep -q "\[x\]" CHECKLIST.md && echo "✅ CHECKLIST 已更新" || echo "❌ CHECKLIST 未更新"
```

**🚨 重要**: 这是 P0 级别要求！未更新 CHECKLIST 视为 Phase 未完成！

---

## 6 种场景流程对照表

| 编号 | 场景 | Phase 0 | Phase 1 | Phase 2 | Phase 4 | Phase 5 |
|------|------|---------|---------|---------|---------|---------|
| 1 | 新-简单 | 可选 | 精简 | 精简+Git | tdd-cycle | 基础验证 |
| 2 | 新-中等 | 推荐 | 完整 | 完整+Git | R→G→R | 完整审核 |
| 3 | 新-复杂 | **必需** | 完整+ADR | 完整+Git | 多工具 | 深度审核 |
| 4 | 老-简单 | 跳过 | 跳过 | 验证+Git | tdd-cycle | 基础验证 |
| 5 | 老-中等 | 推荐 | 检查 | 验证+依赖+Git | R→G→R | 完整审核 |
| 6 | 老-复杂 | **必需** | 检查+更新 | 验证+依赖+Git | 多工具 | 深度审核 |

**图例**:
- ⭐ **必需**: 必须执行
- **推荐**: 强烈建议执行
- 可选: 根据情况决定
- 跳过: 不执行
- 完整: 执行完整流程
- 精简: 执行简化版本
- 验证: 只验证不创建
- R→G→R: RED→GREEN→REFACTOR (分工具执行)
- tdd-cycle: 自动调用 TDD skill（简单项目）
- 多工具: test-automator + python-pro + async-patterns + performance-opt

详细流程参见: [workflow-matrix.md](references/workflow-matrix.md)

---

## 参数解析

接收来自 project-orchestrator 的三维参数：

| 参数 | 值 | 含义 |
|------|-----|------|
| `--new` / `--add-feature` | 项目状态 | 新项目 / 老项目新增功能 |
| `--simple` / `--medium` / `--complex` | 复杂度 | 简单 / 中等 / 复杂 |

---

## Phase 0: 需求分析

| 复杂度 | 新项目 | 老项目新增功能 |
|--------|--------|---------------|
| **简单** | 可选（需求明确时跳过） | 跳过 |
| **中等** | 推荐 | 推荐 |
| **复杂** | ⭐ **必需** | ⭐ **必需** |

**使用 Skill 工具调用**: `superpowers:brainstorming`

**传入**:
- 项目类型提示（新项目 / 老项目新增功能）
- 用户原始需求

**输出**: `docs/plans/YYYY-MM-DD-<feature-name>-design.md`

**验证**: 设计文档已生成

---

## Phase 1: 项目规则

### 新项目模式

| 复杂度 | 执行方式 | 内容 |
|--------|---------|------|
| **简单** | 精简 | 基础 constitution（类型注解、pytest） |
| **中等** | 完整 | 完整 constitution + 质量标准 |
| **复杂** | 完整+ADR | 完整 constitution + ADR 记录 |

**执行步骤**:
1. 调用 `scripts/init_constitution.py` 创建模板
2. 调用 `speckit.constitution` 制定规则

**使用 Skill 工具调用**: `speckit.constitution`

**输出**: `.specify/memory/constitution.md`

**验证**:
```bash
# Constitution 文件已创建
test -f .specify/memory/constitution.md

# CHECKLIST 已更新
grep -q "^\- \[x\] Constitution created/updated" CHECKLIST.md
```

**✅ 完成后更新 CHECKLIST.md**:
```bash
# Phase 1 完成标记
- [x] Constitution created/updated
- [x] Project-specific rules defined
- [x] Coding standards established
- [x] Technical constraints documented
```

### 老项目新增功能模式

| 复杂度 | 执行方式 | 条件 |
|--------|---------|------|
| **简单** | 跳过 | - |
| **中等** | 检查 | 新功能不违反现有规则 |
| **复杂** | 检查+更新 | 新功能需要规则变更 |

**使用 Skill 工具调用**: `speckit.constitution`

**验证**: constitution.md 已更新（如需要）

---

## Phase 2: 项目准备

**核心逻辑**:
1. 检查项目架构是否存在
2. 如果不存在 → 创建完整脚手架
3. 如果已存在 → 检查并补齐缺失部分

**详细指南**: [scaffold-creation.md](references/scaffold-creation.md) - 包含脚手架创建、检查补齐、环境配置、Checklist 初始化

**✅ 完成后更新 CHECKLIST.md**:
```bash
# Phase 2 完成标记
- [x] Project scaffold created
- [x] Directory structure initialized
- [x] System files created (pyproject.toml, .gitignore, Makefile, etc.)
- [x] Dependencies installed (如需要)
- [x] Git repository initialized
- [x] Initial commit created
- [x] CHECKLIST.md created from template
```

---

## Phase 4: TDD 执行 ⭐ 核心

### 🛑 Phase 4 强制性检查点

**在开始 Phase 4 之前，必须确认**：

```bash
# 检查清单（必须全部通过）
[ ] 我没有手动创建任何 .py 文件
[ ] 我没有手动编写任何代码
[ ] 我准备调用工具来完成 TDD
[ ] 我理解等待工具返回是必要的
```

**如果检查失败**：
- ❌ 你手动创建了文件 → **立即删除**，调用工具完成
- ❌ 你想"帮工具一把" → **立即停止**，让工具自己完成

**记住**：工具比手动更可靠、更快速、质量更高！

---

**合规性要求**:
- 📖 **Constitution 合规性**: 参见 [constitution-compliance.md](references/constitution-compliance.md)
- 📋 **Phase 0 需求参考**: 必须参考设计文档（`docs/plans/`）

---

根据**复杂度**选择不同的工具组合。

### 简单项目 - 自动调用 TDD Skill ⭐

**适用场景**: 新-简单、老-简单

**执行方式**:
```python
Skill(skill="tdd-cycle", args="<功能描述>")
```

**详细说明**: [tdd-by-complexity.md](references/tdd-by-complexity.md) - 简单项目部分

**✅ 完成后更新 CHECKLIST.md**:
```bash
# Phase 4 (TDD Cycle) 完成标记
- [x] Tests generated (RED)
- [x] All tests fail with meaningful errors (RED)
- [x] All features implemented (GREEN)
- [x] All tests pass (GREEN)
- [x] Code refactored (REFACTOR)
- [x] All tests still pass (REFACTOR)
- [x] Code quality improved (REFACTOR)
```

---

### 中等项目 - 分工具执行

**适用场景**: 新-中等、老-中等

**🚨 Agent 调用前强制检查清单**:

```
□ 使用 Task 工具（不是 Skill）
□ subagent_type 在第一位
□ 包含 subject（简短标题，imperative form）
□ 包含 description（详细描述）
□ 包含 activeForm（正在进行时）
□ 包含 prompt（完整上下文）
□ 参数顺序符合示例格式
```

**⚠️ 常见错误对照**:

| ❌ 错误 | ✅ 正确 | 说明 |
|------|------|------|
| `description="..."` 在第一位 | `subagent_type="..."` 在第一位 | 参数顺序重要 |
| 无 `subject` | `subject="..."` (必需) | 必须有 subject |
| 无 `activeForm` | `activeForm="..."` (必需) | 必须有 activeForm |
| 凭记忆调用 | 参考下方示例 | 必须遵守格式 |

**参考**: SKILL-IMPROVEMENT-PROPOSAL.md (ERROR-002 解决方案)

**详细流程**: 参见 [tdd-by-complexity.md](references/tdd-by-complexity.md) - 中等项目部分

### 复杂项目 - 多工具组合

**适用场景**: 新-复杂、老-复杂

**详细流程**: 参见 [tdd-by-complexity.md](references/tdd-by-complexity.md) - 复杂项目部分

---

## Phase 5: 质量审核 + Git 完成

### 5.1 质量门控

**运行验证命令**:
```bash
# 所有复杂度都需要
pytest tests/ -v
ruff check src/

# 中等及以上需要
pytest --cov=src --cov-report=term-missing
mypy src/

# 复杂项目额外需要
# 性能分析
# 安全扫描
```

### 5.2 代码审核

**Constitution 合规性检查（强制）**: 参见 [constitution-compliance.md](references/constitution-compliance.md) - Phase 5 质量审核阶段

**✅ 完成后更新 CHECKLIST.md**:
```bash
# Phase 5 完成标记
- [x] All tests pass (100%)
- [x] Coverage meets minimum (80%+)
- [x] Code style checks pass (ruff)
- [x] All changes committed
- [x] CHECKLIST.md committed
- [x] Ready for delivery

# 更新项目完成信息
# Date Completed: <当前日期>
# Completion Status: Complete
```

---

#### 代码审核工具

| 复杂度 | 工具 |
|--------|------|
| **简单** | 跳过或自审 |
| **中等** | `comprehensive-review:code-reviewer` |
| **复杂** | `code-reviewer` + `comprehensive-review:security-auditor` |

### 5.3 Git 完成 ⭐ 仅老项目需要

**适用范围**: 仅老项目新增功能

**使用 Skill**: `superpowers:finishing-a-development-branch`

**选项**: 合并、保留、PR、删除（详见 skill）

---

## References

- [constitution-compliance.md](references/constitution-compliance.md) - Constitution 合规性指南
- [scaffold-creation.md](references/scaffold-creation.md) - 项目脚手架创建指南 ⭐ NEW
- [orchestration-rules.md](references/orchestration-rules.md) - 编排者防错指南
- [project-archetypes.md](references/project-archetypes.md) - 6 种项目架构类型
- [tdd-by-complexity.md](references/tdd-by-complexity.md) - TDD 按复杂度差异化
- [workflow-matrix.md](references/workflow-matrix.md) - 6 种场景完整流程
- [phase-by-complexity.md](references/phase-by-complexity.md) - Phase 0-3 按复杂度差异化
- [checklist-template.md](references/checklist-template.md) - 项目清单模板

---

**文档版本**: 3.4.0
**更新时间**: 2026-02-10
**改进**: P0 修复 - 添加 CHECKLIST.md 自动更新要求（每个 Phase 完成后必须更新 checkbox）
**用途**: Python 项目 TDD 开发编排（支持 6 种场景）

