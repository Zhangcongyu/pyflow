---
name: projectflow-planner
description: |
  根据三维参数（新/老 + 简单/中等/复杂 + 语言类型）检测项目环境，读取综合模板，生成具体可执行的 plan.md。

  触发条件: 由 projectflow-router 调用，传递三维参数和用户需求

  接收参数: --new/--add-feature + --simple/--medium/--complex + --python/--typescript/--go + 用户原始需求 + 当前路径

  核心职责: 检测环境 → 读取模板 → 生成具体可执行的 plan.md → 调用 executor

  整合功能: 原 scaffolder 功能已整合到此 skill
---

# Projectflow Planner

## 核心流程

```
三维参数输入
   ↓
Step 1: 检测项目环境
   ↓
Step 2: 确定版本目录
   ↓
Step 3: 读取综合模板
   ↓
Step 4: 转化模板内容
   ↓
Step 5: 生成 task_plan.md
   ↓
Step 6: 调用 executor
```

---

## Step 1: 检测项目环境

```bash
python .claude/skills/projectflow-planner/scripts/detect_environment.py --json
```

**环境检测结果**:

| 检测项 | 输出字段 | 说明 |
|--------|---------|------|
| Git | `git.exists`, `git.branch` | Git 仓库状态和当前分支 |
| 虚拟环境 | `virtual_env.has_env`, `virtual_env.env_type` | venv/uv/node_modules 等 |
| 项目架构 | `project_structure.has_src_dir`, `project_structure.language` | 目录结构和项目语言 |
| 项目类型 | `project_structure.project_type` | cli/fastapi/django/library/react 等 |

---

## Step 2: 确定版本目录

### pjflow 目录架构

```
项目根目录/pjflow/
├── constitution.md    # 共享宪法文档（项目级）
├── requirements.md      # 共享需求文档（可选）
│
├── v0_initial/        # 初始项目创建
│   ├── task_plan.md
│   ├── progress.md
│   └── findings.md
│
├── v1_add_feature/    # 第1次新增功能
│   ├── task_plan.md
│   ├── progress.md
│   └── findings.md
│
└── v{N}_feature/      # 第N次新增功能
    ├── task_plan.md
    ├── progress.md
    └── findings.md
```

**关键设计原则**:
- `constitution.md` 位于根目录，所有版本共享引用
- `v0_initial` 固定名称
- `v1, v2, ...` 递增版本号
- 每个版本目录包含：task_plan.md, progress.md, findings.md

### 版本目录命名规则

| 项目状态 | 版本目录名称 | 说明 |
|---------|-------------|------|
| new (新建项目) | `v0_initial` | 固定名称 |
| add-feature (新增功能) | `v{N}_{feature_name}` | N 为递增版本号 |

**版本号递增逻辑**:
```bash
existing_versions=$(find ./pjflow -maxdepth 1 -type d -name "v*" 2>/dev/null | sort -V)
if [ -z "$existing_versions" ]; then
    next_version=1
else
    max_version=$(echo "$existing_versions" | tail -1 | sed 's/v//')
    next_version=$((max_version + 1))
fi
echo "下一个版本号: v${next_version}"
```

**feature_name 提取规则**:
- 从用户需求中提取关键词（最多 3 个单词）
- 转为小写，用下划线连接

---

## Step 3: 读取综合模板

| 语言 | 模板文件 | 状态 |
|------|---------|------|
| Python | `assets/templates/python-complete-template.md` | ✅ 完整 |
| TypeScript | `assets/templates/typescript-template.md` | ⚠️ 基础结构 |
| Go | `assets/templates/go-template.md` | ⚠️ 基础结构 |

---

## Step 4: 转化模板内容

**核心任务**: 将描述性模板转化为具体可执行的指令

### 变量替换

| 模板变量 | 替换为 | 来源 |
|---------|--------|------|
| `{{GOAL}}` | 用户原始需求 | router 传入 |
| `{{PROJECT_STATUS}}` | new / add-feature | router 传入 |
| `{{COMPLEXITY}}` | simple / medium / complex | router 传入 |
| `{{LANGUAGE}}` | python / typescript / go | router 传入 |
| `{{VERSION_DIR}}` | v0_initial / v{N}_{feature} | Step 2 计算 |

### Phase 选择

| Phase | new | add-feature |
|-------|-----|-------------|
| Phase 0: 需求互动 | medium/complex | medium/complex |
| Phase 1: 项目规则 | ✅ | ❌ |
| Phase 2: 项目构建 | ✅ | ❌ |
| Phase 3: 工作树准备 | ❌ | ✅ |
| Phase 4: TDD 执行 | ✅ | ✅ |
| Phase 5: 质量审核 | ✅ | ✅ |

---

## Step 5: 生成 task_plan.md

### 5.1 创建版本目录

```bash
mkdir -p pjflow/{{VERSION_DIR}}
```

### 5.2 创建 task_plan.md

**文件路径**: `pjflow/{{VERSION_DIR}}/task_plan.md`

**内容结构**:

```markdown
# 项目执行计划

## 目标
{{GOAL}}

## 参数
- 项目状态: {{PROJECT_STATUS}}
- 复杂度: {{COMPLEXITY}}
- 语言: {{LANGUAGE}}

## Phase 执行计划

### Phase 0: 需求互动 (如适用)
**Tool**: pyflow-brainstorming
**执行**: 探索用户需求

### Phase 1: 项目规则 (新项目)
**Tool**: pyflow-constitution
**执行**: 创建 constitution.md

### Phase 2: 项目构建 (新项目)
详见对应语言模板中的 Phase 2 部分（如 `python-complete-template.md`）

### Phase 3: 工作树准备 (老项目)
详见对应语言模板中的 Phase 3 部分（如 `python-complete-template.md`）

### Phase 4: TDD 执行
**Tool**: pyflow-tdd-cycle (或对应语言 TDD 工具)
**执行**: 根据 `{{COMPLEXITY}}` 选择 TDD 流程

### Phase 5: 质量审核
**Tool**: code-reviewer + Bash
**执行**: 质量检查和 Git 提交

## CHECKLIST
(从模板复制并初始化为全部未选中)
```

### 5.3 创建 progress.md 和 findings.md

**progress.md**: 记录执行日志
**findings.md**: 记录知识库和发现

---

## Step 6: 调用 executor

```bash
Skill(skill="projectflow-executor", args="")
```

---

## References

### scripts/

| 文件 | 说明 |
|------|------|
| `detect_environment.py` | 多语言环境检测脚本 |

### assets/templates/

| 文件 | 说明 | 状态 |
|------|------|------|
| `python-complete-template.md` | Python 完整模板（Phase 0-5，simple/medium/complex） | ✅ 完整 |
| `typescript-template.md` | TypeScript 基础模板 | ✅ 基础结构 |
| `go-template.md` | Go 基础模板 | ✅ 基础结构 |

---

**版本**: 4.0.0
**用途**: ProjectFlow Planner - 环境检测 + 模板转化 + 计划生成
**更新**:
- 整合 scaffolder 功能
- 模板路径调整（扁平化到 templates/ 目录）
- 新增 Phase 2.0 干扰检测与清理
- 扩展 Phase 3 旧项目工作流程
- 新增 TypeScript 和 Go 基础模板
