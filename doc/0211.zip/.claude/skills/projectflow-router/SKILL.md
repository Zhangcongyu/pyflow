---
name: projectflow-router
description: |
  三维检测器，检测项目属性（新/老 + 简单/中等/复杂 + 语言类型）并路由到 projectflow-planner。

  **触发条件**: 用户请求项目开发、创建应用、添加功能

  **检测维度**:
  1. 项目状态: 新项目 (--new) vs 老项目新增功能 (--add-feature)
  2. 项目复杂度: 简单 (--simple) vs 中等 (--medium) vs 复杂 (--complex)
  3. 语言类型: Python (--python) vs TypeScript (--typescript) vs Go (--go)

  **核心原则**: 纯检测器，只负责参数传递
  - ✅ 检测三维参数，传递给 projectflow-planner
  - ❌ 不创建文件、不执行任何实现工作
---

# Projectflow Router

## 核心职责

**唯一职责**: 三维检测 + 调用 projectflow-planner

```
用户请求
   ↓
检测 1: 新项目 vs 老项目？
检测 2: 简单 vs 中等 vs 复杂？
检测 3: 什么语言？
   ↓
调用 projectflow-planner（传递三维参数 + 用户需求）
```

---

## 维度 1: 项目类型检测（新 vs 老）

### 新项目信号 (--new)

| 用户语言 | 判断依据 |
|---------|---------|
| "创建"、"新建"、"build from scratch" | 新项目 |
| "初始化"、"start a new project" | 新项目 |
| 当前目录为空或没有项目文件 | 新项目 |
| 不存在 `pyproject.toml`, `package.json` 等 | 新项目 |

### 老项目信号 (--add-feature)

| 用户语言 | 判断依据 |
|---------|---------|
| "添加"、"新增"、"extend"、"add feature" | 老项目新增功能 |
| "在现有项目..." | 老项目 |
| 存在项目配置文件 | 老项目 |

---

## 维度 2: 项目复杂度检测

### 简单项目 (--simple)

**特征** (< 300 LOC):
- 用户语言: "简单"、"小的"、"quick"、"一个脚本"、"单个功能"、"工具"、"utility"
- 技术信号: 单一功能，明确需求，无复杂架构

### 中等项目 (--medium)

**特征** (300-1000 LOC):
- 用户语言: "中等"、"几个功能"
- 技术信号: "API"、"CRUD"、"数据处理"、"service"，多相关功能，需要一定架构设计

### 复杂项目 (--complex)

**特征** (> 1000 LOC):
- 用户语言: "复杂"、"大型的"、"完整系统"
- 技术信号: "平台"、"框架"、"microservices"，"高性能"、"分布式"、"异步"，多模块，需要详细架构和规划

---

## 维度 3: 语言类型检测

| 触发关键词 | 参数 |
|-----------|------|
| Python, FastAPI, Django, Flask, asyncio, SQLAlchemy, pytest | `--python` |
| TypeScript, JavaScript, Node.js, Express, NestJS, React, Next.js | `--typescript` |
| Go, Golang, Gin, Gorm | `--go` |

**默认值**: 如果未明确指定语言，默认使用 `--python`

---

## 路由决策表

| 编号 | 项目状态 | 复杂度 | 语言 | 参数组合 |
|------|---------|--------|------|---------|
| 1 | 新项目 | 简单 | Python | `--new --simple --python` |
| 2 | 新项目 | 中等 | Python | `--new --medium --python` |
| 3 | 新项目 | 复杂 | Python | `--new --complex --python` |
| 4 | 老项目 | 简单 | Python | `--add-feature --simple --python` |
| 5 | 老项目 | 中等 | Python | `--add-feature --medium --python` |
| 6 | 老项目 | 复杂 | Python | `--add-feature --complex --python` |

---

## 执行流程

### Step 1: 检测项目状态

分析用户请求和当前目录状态：
- **新项目**: 用户说"创建"+"目录为空/无配置文件" → `--new`
- **老项目**: 用户说"添加"+"有配置文件" → `--add-feature`

**验证命令** (可选):
```bash
# 检查是否存在项目文件
test -f pyproject.toml && echo "Old project" || echo "New project"
test -f package.json && echo "Old project" || echo "New project"
```

### Step 2: 检测项目复杂度

分析用户请求中的关键词：
- **简单**: "简单"、"小的"、"一个脚本"、"工具" → `--simple`
- **中等**: "API"、"CRUD"、"几个功能"、"service" → `--medium`
- **复杂**: "平台"、"系统"、"框架"、"高性能" → `--complex`

### Step 3: 检测语言类型

分析用户请求中的技术关键词：
- **Python**: "Python", "FastAPI", "Django", "Flask" → `--python`
- **TypeScript**: "TypeScript", "Node.js", "Express", "React" → `--typescript`
- **Go**: "Go", "Golang", "Gin" → `--go`

### Step 4: 调用 projectflow-planner

使用 **Skill 工具**传递检测到的三维参数：

```
调用: projectflow-planner

传入参数:
- 三维参数: --new --simple --python
- 用户需求: <原始用户请求>
- 当前路径: <工作目录>

要求:
- 根据三维参数选择对应模板
- 生成 task_plan.md
- 创建 progress.md 和 findings.md
```

---

## 调用示例

### 示例 1: 新建简单 Python 项目

**用户请求**: "创建一个简单的 CLI 待办事项工具"

**检测过程**:
1. 项目状态: "创建" → `--new`
2. 复杂度: "简单的" → `--simple`
3. 语言: 默认 Python → `--python`

**调用**:
```
Skill(skill="projectflow-planner", args="--new --simple --python 创建一个简单的 CLI 待办事项工具")
```

### 示例 2: 在现有项目添加中等复杂功能

**用户请求**: "在当前项目添加一个 FastAPI CRUD 接口"

**检测过程**:
1. 项目状态: "添加" → `--add-feature`
2. 复杂度: "API"、"CRUD" → `--medium`
3. 语言: "FastAPI" → `--python`

**调用**:
```
Skill(skill="projectflow-planner", args="--add-feature --medium --python 在当前项目添加一个 FastAPI CRUD 接口")
```

### 示例 3: 新建复杂系统

**用户请求**: "创建一个高性能的异步任务处理平台"

**检测过程**:
1. 项目状态: "创建" → `--new`
2. 复杂度: "平台"、"高性能" → `--complex`
3. 语言: 默认 Python → `--python`

**调用**:
```
Skill(skill="projectflow-planner", args="--new --complex --python 创建一个高性能的异步任务处理平台")
```

---

## Resources

### references/

详见 [detection-criteria.md](references/detection-criteria.md) - 详细的检测标准和示例

---

**版本**: 1.0.0
**用途**: ProjectFlow 架构 - 三维检测器
