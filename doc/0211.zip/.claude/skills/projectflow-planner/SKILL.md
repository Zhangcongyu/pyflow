---
name: projectflow-planner
description: |
  根据三维参数（新/老 + 简单/中等/复杂 + 语言类型）选择对应模板，生成 task_plan.md、progress.md、findings.md。

  **触发条件**: 由 projectflow-router 调用，传递三维参数和用户需求

  **接收参数**:
  - 三维参数: --new/--add-feature + --simple/--medium/--complex + --python/--typescript/--go
  - 用户需求: 原始用户请求描述
  - 当前路径: 工作目录

  **核心职责**: 选择模板 → 生成计划文件 → 调用 projectflow-executor
  - ✅ 根据三维参数选择对应的流程模板
  - ✅ 生成 task_plan.md（完整的项目流程计划）
  - ✅ 创建 progress.md（会话日志）
  - ✅ 创建 findings.md（知识库）
  - ❌ 不执行任何实现工作
---

# Projectflow Planner

## 核心职责

根据三维参数选择对应模板，生成项目计划文件：

```
三维参数输入
   ↓
选择对应模板
   ↓
生成 task_plan.md
创建 progress.md
创建 findings.md
   ↓
调用 projectflow-executor
```

---

## 模板选择逻辑

### 三维参数到模板的映射

| 项目状态 | 复杂度 | 语言 | 模板文件 |
|---------|--------|------|----------|
| new | simple | python | `templates/python/task_plan_new_simple.md` |
| new | medium | python | `templates/python/task_plan_new_medium.md` |
| new | complex | python | `templates/python/task_plan_new_complex.md` |
| add-feature | simple | python | `templates/python/task_plan_add_simple.md` |
| add-feature | medium | python | `templates/python/task_plan_add_medium.md` |
| add-feature | complex | python | `templates/python/task_plan_add_complex.md |

**未来扩展**: TypeScript 和 Go 的模板（当前预留目录）

---

## 执行流程

### Step 1: 解析三维参数

从传入的参数中提取：

```bash
# 示例输入
--new --simple --python 创建一个待办事项应用

# 解析结果
PROJECT_STATUS=new
COMPLEXITY=simple
LANGUAGE=python
USER_REQUEST="创建一个待办事项应用"
```

### Step 2: 选择对应模板

根据三维参数组合选择模板：

```
if PROJECT_STATUS == "new" and COMPLEXITY == "simple" and LANGUAGE == "python":
    TEMPLATE = "templates/python/task_plan_new_simple.md"
elif PROJECT_STATUS == "new" and COMPLEXITY == "medium" and LANGUAGE == "python":
    TEMPLATE = "templates/python/task_plan_new_medium.md"
# ... 其他组合
```

**使用 Read 工具读取模板内容**

### Step 3: 生成 task_plan.md

1. 读取选定的模板文件
2. 替换模板变量：
   - `{{GOAL}}` → 用户需求
3. 使用 **Write 工具**写入 `./pjflow/` 目录

**输出文件**: `./pjflow/task_plan.md`

### Step 4: 创建 progress.md

1. 读取通用模板 `templates/progress.md`
2. 使用 **Write 工具**写入 `./pjflow/` 目录

**输出文件**: `./pjflow/progress.md`

### Step 5: 创建 findings.md

1. 读取通用模板 `templates/findings.md`
2. 使用 **Write 工具**写入 `./pjflow/` 目录

**输出文件**: `./pjflow/findings.md`

### Step 6: 调用 projectflow-executor

使用 **Skill 工具**调用执行器：

```
Skill(skill="projectflow-executor", args="")
```

**要求**:
- 读取 ./pjflow/task_plan.md
- 逐阶段执行
- 更新 ./pjflow/progress.md
- 更新 CHECKLIST.md

---

## 模板变量

### task_plan.md 模板变量

| 变量 | 说明 | 示例值 |
|------|------|--------|
| `{{GOAL}}` | 用户原始需求 | "创建一个 FastAPI 待办事项应用" |

### 替换示例

**模板内容**:
```markdown
## Goal
{{GOAL}}
```

**替换后**:
```markdown
## Goal
创建一个 FastAPI 待办事项应用
```

---

## 执行示例

### 示例 1: 新-简单项目

**输入**:
```
--new --simple --python 创建一个简单的 CLI 待办事项工具
```

**执行流程**:
1. 选择模板: `task_plan_new_simple.md`
2. 替换 `{{GOAL}}` → "创建一个简单的 CLI 待办事项工具"
3. 创建 `./pjflow/task_plan.md`
4. 创建 `./pjflow/progress.md`
5. 创建 `./pjflow/findings.md`
6. 调用 `projectflow-executor`

**生成的 task_plan.md 包含**:
- Phase 1: 项目规则（精简）
- Phase 2: 项目准备（精简）
- Phase 4: TDD 执行（tdd-cycle）
- Phase 5: 质量审核（基础）

### 示例 2: 老-中等项目

**输入**:
```
--add-feature --medium --python 在当前项目添加 FastAPI CRUD 接口
```

**执行流程**:
1. 选择模板: `task_plan_add_medium.md`
2. 替换 `{{GOAL}}` → "在当前项目添加 FastAPI CRUD 接口"
3. 创建 `./pjflow/task_plan.md`
4. 创建 `./pjflow/progress.md`
5. 创建 `./pjflow/findings.md`
6. 调用 `projectflow-executor`

**生成的 task_plan.md 包含**:
- Phase 0: 需求分析（推荐）
- Phase 1: 检查 Constitution
- Phase 2: 验证 + 依赖 + Worktree
- Phase 4: TDD 执行（分工具）
- Phase 5: 质量审核 + Git 完成

---

## 错误处理

### 模板不存在

如果三维参数组合对应的模板不存在：

1. 记录错误到 progress.md
2. 使用默认模板（新-中等）
3. 继续执行

### 模板变量替换失败

如果 `{{GOAL}}` 等变量未替换：

1. 保留原始模板变量
2. 在 progress.md 中记录警告
3. 继续执行

---

## Resources

### assets/templates/

包含所有流程模板：

- `task_plan.md` - 通用模板
- `findings.md` - 知识库模板
- `progress.md` - 会话日志模板
- `python/` - Python 流程模板（6个）
  - `task_plan_new_simple.md`
  - `task_plan_new_medium.md`
  - `task_plan_new_complex.md`
  - `task_plan_add_simple.md`
  - `task_plan_add_medium.md`
  - `task_plan_add_complex.md
- `typescript/` - TypeScript 流程模板（预留）
- `go/` - Go 流程模板（预留）

详见 [workflow-mapping.md](references/workflow-mapping.md) - 完整的模板映射表

---

**版本**: 1.0.0
**用途**: ProjectFlow 架构 - 计划生成器
