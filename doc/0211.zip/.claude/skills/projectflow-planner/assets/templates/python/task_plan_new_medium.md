# Task Plan: {{GOAL}}

## Goal
{{GOAL}}

## Current Phase
Phase 0

## Scenario
新-中等项目 (New-Medium)

## Phases

### Phase 0: 需求分析
- Description: 推荐执行 brainstorming 明确需求
- Tool: pyflow-brainstorming
- Tool Type: Skill
- Args: 项目类型提示（新项目）+ 用户需求
- Output: ./pjflow/requirements.md
- CHECKLIST:
  - [ ] Requirements clarified
  - [ ] Design document created
  - [ ] Technical approach defined
  - [ ] Compliance: Requirements document created and validated
- Status: pending

### Phase 1: 项目规则
- Description: 创建完整 constitution + 质量标准
- Tool: pyflow-constitution
- Tool Type: Skill
- Args: --medium
- CHECKLIST:
  - [ ] Constitution created/updated
  - [ ] Project-specific rules defined
  - [ ] Coding standards established
  - [ ] Technical constraints documented
  - [ ] Quality standards defined
  - [ ] Compliance: Constitution verified (no placeholders)
- Status: pending

### Phase 4: TDD 执行

#### Phase 4.1: RED - 生成测试
- Description: 生成完整测试套件
- Tool: pyflow-test-automator
- Tool Type: Task (subagent_type)
- Args: 功能需求描述
- CHECKLIST:
  - [ ] Test files generated
  - [ ] Test structure defined
  - [ ] Test cases cover requirements
  - [ ] Compliance: Tests cover Requirements and Constitution standards
- Status: pending

#### Phase 4.2: GREEN - 实现功能
- Description: 实现所有功能使测试通过
- Tool: pyflow-python-pro
- Tool Type: Task (subagent_type)
- Args: 测试文件路径 + 功能需求
- CHECKLIST:
  - [ ] All features implemented
  - [ ] All tests pass
  - [ ] Code follows constitution
  - [ ] Compliance: Code within Requirements scope, follows Constitution standards
- Status: pending

#### Phase 4.3: REFACTOR - 重构代码
- Description: 优化代码结构和质量
- Tool: pyflow-python-pro
- Tool Type: Task (subagent_type)
- Args: 重构目标 + 当前代码
- CHECKLIST:
  - [ ] Code refactored
  - [ ] All tests still pass
  - [ ] Code quality improved
  - [ ] Performance optimized (if needed)
  - [ ] Compliance: Refactor preserves Constitution compliance
- Status: pending

### Phase 5: 质量审核

#### Phase 5.1: 质量门控
- Description: 完整验证（pytest + mypy + ruff + coverage）
- Tool: bash
- Tool Type: Command
- Args: |
  pytest tests/ -v
  pytest --cov=src --cov-report=term-missing
  ruff check src/
  mypy src/
- CHECKLIST:
  - [ ] All tests pass (100%)
  - [ ] Coverage meets minimum (80%+)
  - [ ] Code style checks pass (ruff)
  - [ ] Type checks pass (mypy)
  - [ ] Compliance: Code follows Constitution style and type standards
- Status: pending

#### Phase 5.2: 代码审核
- Description: 完整代码审核
- Tool: pyflow-code-reviewer
- Tool Type: Task (subagent_type)
- Args: 项目根目录
- CHECKLIST:
  - [ ] Code review completed
  - [ ] Issues documented (if any)
  - [ ] Constitution compliance verified
  - [ ] Requirements compliance verified
  - [ ] Compliance report generated
- Status: pending

---

**预计时间**: 2-4 小时
