# Task Plan: {{GOAL}}

## Goal
{{GOAL}}

## Current Phase
Phase 1

## Scenario
新-简单项目 (New-Simple)

## Phases

### Phase 1: 项目规则
- Description: 创建精简 constitution（基础类型注解、pytest 要求）
- Tool: pyflow-constitution
- Tool Type: Skill
- Args: --simple
- CHECKLIST:
  - [ ] Constitution created/updated
  - [ ] Project-specific rules defined
  - [ ] Coding standards established
  - [ ] Technical constraints documented
  - [ ] Compliance: Constitution verified (no placeholders)
- Status: pending

### Phase 4: TDD 执行
- Description: 完整 TDD 流程（RED → GREEN → REFACTOR）
- Tool: pyflow-tdd-cycle
- Tool Type: Skill
- Args: {{GOAL}}
- CHECKLIST:
  - [ ] Tests generated (RED)
  - [ ] All tests fail with meaningful errors (RED)
  - [ ] Compliance: Tests cover Constitution quality standards (RED)
  - [ ] All features implemented (GREEN)
  - [ ] All tests pass (GREEN)
  - [ ] Compliance: Code follows Constitution requirements (GREEN)
  - [ ] Code refactored (REFACTOR)
  - [ ] All tests still pass (REFACTOR)
  - [ ] Code quality improved (REFACTOR)
  - [ ] Compliance: Refactor preserves Constitution compliance (REFACTOR)
- Status: pending

### Phase 5: 质量审核
- Description: 基础验证（pytest + ruff）
- Tool: bash
- Tool Type: Command
- Args: pytest tests/ -v && ruff check src/
- CHECKLIST:
  - [ ] All tests pass (100%)
  - [ ] Code style checks pass (ruff)
  - [ ] Ready for delivery
  - [ ] Compliance: Code follows Constitution standards
- Status: pending

---

**预计时间**: 30-60 分钟
**跳过的环节**: Phase 0 (brainstorming), Phase 5.2 (code-reviewer)
