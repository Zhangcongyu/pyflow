# Task Plan: {{GOAL}}

## Goal
{{GOAL}}

## Current Phase
Phase 0

## Scenario
新-复杂项目 (New-Complex)

## Phases

### Phase 0: 需求分析
- Description: ⭐ 必需执行 brainstorming + 详细架构设计
- Tool: pyflow-brainstorming
- Tool Type: Skill
- Args: 项目类型提示（新项目 + 复杂）+ 用户需求
- Output: ./pjflow/requirements.md
- CHECKLIST:
  - [ ] Requirements fully clarified
  - [ ] Architecture design document created
  - [ ] Technical approach defined
  - [ ] Performance requirements identified
  - [ ] Security requirements documented
  - [ ] Compliance: Requirements document created and validated
- Status: pending

### Phase 1: 项目规则
- Description: 创建完整 constitution + ADR 记录
- Tool: pyflow-constitution
- Tool Type: Skill
- Args: --complex
- CHECKLIST:
  - [ ] Constitution created/updated
  - [ ] Project-specific rules defined
  - [ ] Coding standards established
  - [ ] Technical constraints documented
  - [ ] Quality standards defined
  - [ ] ADR process initialized
  - [ ] Compliance: Constitution verified (no placeholders)
- Status: pending

### Phase 4: TDD 执行

#### Phase 4.1: RED - 生成测试
- Description: 生成完整测试套件（包含性能和安全测试）
- Tool: pyflow-test-automator
- Tool Type: Task (subagent_type)
- Args: 功能需求描述 + 性能要求 + 安全要求
- CHECKLIST:
  - [ ] Test files generated
  - [ ] Unit tests defined
  - [ ] Integration tests defined
  - [ ] Performance tests defined
  - [ ] Security tests defined
  - [ ] Compliance: Tests cover Requirements and Constitution standards
- Status: pending

#### Phase 4.2: GREEN - 基础实现
- Description: 实现基础功能
- Tool: pyflow-python-pro
- Tool Type: Task (subagent_type)
- Args: 测试文件路径 + 功能需求
- CHECKLIST:
  - [ ] All features implemented
  - [ ] All tests pass
  - [ ] Code follows constitution
  - [ ] Compliance: Code within Requirements scope, follows Constitution standards
- Status: pending

#### Phase 4.3: GREEN - 异步优化
- Description: 添加异步支持（如需要）
- Tool: pyflow-async-python-patterns
- Tool Type: Skill
- Args: 当前代码 + 异步需求
- CHECKLIST:
  - [ ] Async patterns implemented
  - [ ] All tests still pass
  - [ ] Performance improved
  - [ ] Compliance: Async patterns follow Constitution requirements
- Status: pending

#### Phase 4.4: GREEN - 性能优化
- Description: 性能分析和优化
- Tool: pyflow-python-performance-optimization
- Tool Type: Skill
- Args: 当前代码 + 性能目标
- CHECKLIST:
  - [ ] Performance profiled
  - [ ] Bottlenecks identified
  - [ ] Optimizations applied
  - [ ] Performance targets met
  - [ ] Compliance: Performance optimizations meet Requirements targets
- Status: pending

#### Phase 4.5: REFACTOR - 性能优化
- Description: 深度性能优化
- Tool: pyflow-python-performance-optimization
- Tool Type: Task (subagent_type)
- Args: 重构目标 + 当前代码
- CHECKLIST:
  - [ ] Advanced optimizations applied
  - [ ] All tests still pass
  - [ ] Performance significantly improved
  - [ ] Compliance: Refactor preserves Constitution compliance
- Status: pending

#### Phase 4.6: REFACTOR - 最终清理
- Description: 最终代码清理和文档
- Tool: pyflow-python-pro
- Tool Type: Task (subagent_type)
- Args: 清理目标 + 当前代码
- CHECKLIST:
  - [ ] Code cleaned up
  - [ ] Documentation updated
  - [ ] All tests pass
  - [ ] Code quality excellent
  - [ ] Compliance: Final code follows all Constitution standards
- Status: pending

### Phase 5: 质量审核

#### Phase 5.1: 深度验证
- Description: 完整验证 + 性能分析
- Tool: bash
- Tool Type: Command
- Args: |
  pytest tests/ -v
  pytest --cov=src --cov-report=term-missing
  ruff check src/
  mypy src/
  python -m cProfile -o profile.stats
- CHECKLIST:
  - [ ] All tests pass (100%)
  - [ ] Coverage meets minimum (80%+)
  - [ ] Code style checks pass (ruff)
  - [ ] Type checks pass (mypy)
  - [ ] Performance profile analyzed
  - [ ] Performance targets met
  - [ ] Compliance: Code follows Constitution standards
- Status: pending

#### Phase 5.2: 完整审核
- Description: 代码审核 + 安全审核
- Tool: pyflow-code-reviewer
- Tool Type: Task (subagent_type)
- Args: 项目根目录
- CHECKLIST:
  - [ ] Code review completed
  - [ ] Issues documented (if any)
  - [ ] Constitution compliance verified
  - [ ] Requirements compliance verified
  - [ ] Compliance report generated
- Status: pending

#### Phase 5.3: 安全审核
- Description: 安全漏洞扫描
- Tool: pyflow-security-auditor
- Tool Type: Task (subagent_type)
- Args: 项目根目录
- CHECKLIST:
  - [ ] Security audit completed
  - [ ] Vulnerabilities documented (if any)
  - [ ] Security best practices verified
  - [ ] Compliance: Security requirements from Requirements met
- Status: pending

---

**预计时间**: 1-3 天
**Git 状态**: 已在主支（main/master）开发，无需额外 Git 操作
