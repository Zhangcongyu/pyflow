# Task Plan: {{GOAL}}

## Goal
{{GOAL}}

## Current Phase
Phase 0

## Scenario
老-中等项目 (Add-Medium)

## Phases

### Phase 0: 需求分析
- Description: 推荐执行 brainstorming
- Tool: pyflow-brainstorming
- Tool Type: Skill
- Args: 项目类型提示（老项目新增功能）+ 用户需求
- Output: ./pjflow/requirements.md
- CHECKLIST:
  - [ ] Requirements clarified
  - [ ] Design document created
  - [ ] Integration approach defined
  - [ ] Compliance: Requirements document created and validated
- Status: pending

### Phase 1: 检查 Constitution
- Description: 检查现有 constitution，确保新功能不违反规则
- Tool: pyflow-constitution
- Tool Type: Skill
- Args: --check
- CHECKLIST:
  - [ ] Constitution reviewed
  - [ ] New feature compliant with rules
  - [ ] Updates documented (if needed)
  - [ ] Compliance: New feature follows existing Constitution
- Status: pending

### Phase 2.1: 标准验证
- Description: 验证现有项目环境
- Tool: bash
- Tool Type: Command
- Args: test -d .venv && test -f pyproject.toml
- CHECKLIST:
  - [ ] Virtual environment exists
  - [ ] Project configuration valid
- Status: pending

### Phase 2.2: 添加依赖
- Description: 添加新功能所需的依赖
- Tool: pyflow-uv-package-manager
- Tool Type: Skill
- Args: add <new-dependencies>
- CHECKLIST:
  - [ ] Dependencies identified
  - [ ] Dependencies added
  - [ ] Virtual environment updated
- Status: pending

### Phase 2.3: 创建 Worktree
- Description: 创建 Git worktree 隔离开发
- Tool: pyflow-using-git-worktrees
- Tool Type: Skill
- Args: feature-branch-name
- CHECKLIST:
  - [ ] Git worktree created
  - [ ] Feature branch created
  - [ ] Working directory switched
- Status: pending

### Phase 4: TDD 执行

#### Phase 4.1: RED - 生成测试
- Description: 生成测试套件
- Tool: pyflow-test-automator
- Tool Type: Task (subagent_type)
- Args: 功能需求描述
- CHECKLIST:
  - [ ] Test files generated
  - [ ] Test structure defined
  - [ ] Test cases cover requirements
  - [ ] Compliance: Tests cover Requirements and Constitution standards
- Status: pending

#### Phase 4.2: GREEN - 实现功能
- Description: 实现功能使测试通过
- Tool: pyflow-python-pro
- Tool Type: Task (subagent_type)
- Args: 测试文件路径 + 功能需求
- CHECKLIST:
  - [ ] All features implemented
  - [ ] All tests pass
  - [ ] Code follows constitution
  - [ ] Compliance: Code within Requirements scope, follows Constitution standards
- Status: pending

#### Phase 4.3: REFACTOR - 重构代码
- Description: 优化代码
- Tool: pyflow-python-pro
- Tool Type: Task (subagent_type)
- Args: 重构目标 + 当前代码
- CHECKLIST:
  - [ ] Code refactored
  - [ ] All tests still pass
  - [ ] Code quality improved
  - [ ] Compliance: Refactor preserves Constitution compliance
- Status: pending

### Phase 5: 质量审核

#### Phase 5.1: 质量门控
- Description: 完整验证
- Tool: bash
- Tool Type: Command
- Args: |
  pytest tests/ -v
  pytest --cov=src --cov-report=term-missing
  ruff check src/
  mypy src/
- CHECKLIST:
  - [ ] All tests pass (100%)
  - [ ] Coverage meets minimum (80%+)
  - [ ] Code style checks pass (ruff)
  - [ ] Type checks pass (mypy)
  - [ ] Compliance: Code follows Constitution standards
- Status: pending

#### Phase 5.2: 代码审核
- Description: 完整代码审核
- Tool: pyflow-code-reviewer
- Tool Type: Task (subagent_type)
- Args: 项目根目录
- CHECKLIST:
  - [ ] Code review completed
  - [ ] Issues documented (if any)
  - [ ] Constitution compliance verified
  - [ ] Requirements compliance verified
  - [ ] Compliance report generated
- Status: pending

#### Phase 5.3: Git 完成
- Description: 完成功能分支
- Tool: pyflow-finishing-a-development-branch
- Tool Type: Skill
- Args: --merge
- CHECKLIST:
  - [ ] All changes committed
  - [ ] Feature branch merged
  - [ ] Worktree cleaned up
  - [ ] CHECKLIST.md committed
  - [ ] Compliance: All changes follow Constitution
- Status: pending

---

**预计时间**: 2-4 小时
