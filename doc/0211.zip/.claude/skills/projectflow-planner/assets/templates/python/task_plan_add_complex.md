# Task Plan: {{GOAL}}

## Goal
{{GOAL}}

## Current Phase
Phase 0

## Scenario
老-复杂项目 (Add-Complex)

## Phases

### Phase 0: 需求分析
- Description: ⭐ 必需执行 brainstorming + 详细架构设计
- Tool: pyflow-brainstorming
- Tool Type: Skill
- Args: 项目类型提示（老项目 + 复杂功能）+ 用户需求
- Output: ./pjflow/requirements.md
- CHECKLIST:
  - [ ] Requirements fully clarified
  - [ ] Architecture design updated
  - [ ] Integration approach defined
  - [ ] Performance impact analyzed
  - [ ] Security impact documented
  - [ ] Compliance: Requirements document created and validated
- Status: pending

### Phase 1: 检查并更新 Constitution
- Description: 检查现有 constitution，更新规则（如需要）
- Tool: pyflow-constitution
- Tool Type: Skill
- Args: --update
- CHECKLIST:
  - [ ] Constitution reviewed
  - [ ] New feature requirements analyzed
  - [ ] Rules updated (if needed)
  - [ ] ADR created (if major change)
  - [ ] Compliance: New feature follows existing Constitution
- Status: pending

### Phase 2.1: 深度验证
- Description: 验证现有项目环境
- Tool: bash
- Tool Type: Command
- Args: |
  test -d .venv
  test -f pyproject.toml
  pytest tests/ -v
- CHECKLIST:
  - [ ] Virtual environment exists
  - [ ] Project configuration valid
  - [ ] Existing tests pass
- Status: pending

### Phase 2.2: 添加依赖
- Description: 添加新功能所需的依赖
- Tool: pyflow-uv-package-manager
- Tool Type: Skill
- Args: add <new-dependencies>
- CHECKLIST:
  - [ ] Dependencies identified
  - [ ] Dependencies added
  - [ ] Virtual environment updated
  - [ ] Dependency conflicts resolved
- Status: pending

### Phase 2.3: 创建 Worktree
- Description: 创建 Git worktree 隔离开发
- Tool: pyflow-using-git-worktrees
- Tool Type: Skill
- Args: feature-branch-name
- CHECKLIST:
  - [ ] Git worktree created
  - [ ] Feature branch created
  - [ ] Working directory switched
- Status: pending

### Phase 4: TDD 执行

#### Phase 4.1: RED - 生成测试
- Description: 生成完整测试套件
- Tool: pyflow-test-automator
- Tool Type: Task (subagent_type)
- Args: 功能需求描述 + 性能要求 + 安全要求
- CHECKLIST:
  - [ ] Test files generated
  - [ ] Unit tests defined
  - [ ] Integration tests defined
  - [ ] Performance tests defined
  - [ ] Security tests defined
  - [ ] Compliance: Tests cover Requirements and Constitution standards
- Status: pending

#### Phase 4.2: GREEN - 基础实现
- Description: 实现基础功能
- Tool: pyflow-python-pro
- Tool Type: Task (subagent_type)
- Args: 测试文件路径 + 功能需求
- CHECKLIST:
  - [ ] All features implemented
  - [ ] All tests pass
  - [ ] Code follows constitution
  - [ ] Compliance: Code within Requirements scope, follows Constitution standards
- Status: pending

#### Phase 4.3: GREEN - 异步优化
- Description: 添加异步支持（如需要）
- Tool: pyflow-async-python-patterns
- Tool Type: Task (subagent_type)
- Args: 当前代码 + 异步需求
- CHECKLIST:
  - [ ] Async patterns implemented
  - [ ] All tests still pass
  - [ ] Performance improved
  - [ ] Compliance: Async patterns follow Constitution requirements
- Status: pending

#### Phase 4.4: GREEN - 性能优化
- Description: 性能分析和优化
- Tool: pyflow-python-performance-optimization
- Tool Type: Task (subagent_type)
- Args: 当前代码 + 性能目标
- CHECKLIST:
  - [ ] Performance profiled
  - [ ] Bottlenecks identified
  - [ ] Optimizations applied
  - [ ] Performance targets met
  - [ ] Compliance: Performance optimizations meet Requirements targets
- Status: pending

#### Phase 4.5: REFACTOR - 性能优化
- Description: 深度性能优化
- Tool: pyflow-python-performance-optimization
- Tool Type: Task (subagent_type)
- Args: 重构目标 + 当前代码
- CHECKLIST:
  - [ ] Advanced optimizations applied
  - [ ] All tests still pass
  - [ ] Performance significantly improved
  - [ ] Compliance: Refactor preserves Constitution compliance
- Status: pending

#### Phase 4.6: REFACTOR - 最终清理
- Description: 最终代码清理和文档
- Tool: pyflow-python-pro
- Tool Type: Task (subagent_type)
- Args: 清理目标 + 当前代码
- CHECKLIST:
  - [ ] Code cleaned up
  - [ ] Documentation updated
  - [ ] All tests pass
  - [ ] Code quality excellent
  - [ ] Compliance: Final code follows all Constitution standards
- Status: pending

### Phase 5: 质量审核

#### Phase 5.1: 深度验证
- Description: 完整验证 + 性能分析
- Tool: bash
- Tool Type: Command
- Args: |
  pytest tests/ -v
  pytest --cov=src --cov-report=term-missing
  ruff check src/
  mypy src/
  python -m cProfile -o profile.stats
- CHECKLIST:
  - [ ] All tests pass (100%)
  - [ ] Coverage meets minimum (80%+)
  - [ ] Code style checks pass (ruff)
  - [ ] Type checks pass (mypy)
  - [ ] Performance profile analyzed
  - [ ] Performance targets met
  - [ ] Compliance: Code follows Constitution standards
- Status: pending

#### Phase 5.2: 完整审核
- Description: 代码审核 + 安全审核
- Tool: pyflow-code-reviewer
- Tool Type: Task (subagent_type)
- Args: 项目根目录
- CHECKLIST:
  - [ ] Code review completed
  - [ ] Issues documented (if any)
  - [ ] Constitution compliance verified
  - [ ] Requirements compliance verified
  - [ ] Compliance report generated
- Status: pending

#### Phase 5.3: 安全审核
- Description: 安全漏洞扫描
- Tool: pyflow-security-auditor
- Tool Type: Task (subagent_type)
- Args: 项目根目录
- CHECKLIST:
  - [ ] Security audit completed
  - [ ] Vulnerabilities documented (if any)
  - [ ] Security best practices verified
  - [ ] Compliance: Security requirements from Requirements met
- Status: pending

#### Phase 5.4: Git 完成
- Description: 完成功能分支
- Tool: pyflow-finishing-a-development-branch
- Tool Type: Skill
- Args: --merge
- CHECKLIST:
  - [ ] All changes committed
  - [ ] Feature branch merged
  - [ ] Worktree cleaned up
  - [ ] CHECKLIST.md committed
  - [ ] Compliance: All changes follow Constitution
- Status: pending

---

**预计时间**: 1-3 天
