# Task Plan: {{GOAL}}

## Goal
{{GOAL}}

## Current Phase
Phase 2

## Scenario
老-简单项目 (Add-Simple)

## Phases

### Phase 2.1: 基础验证
- Description: 验证现有项目环境
- Tool: bash
- Tool Type: Command
- Args: test -d .venv && test -f pyproject.toml
- CHECKLIST:
  - [ ] Virtual environment exists
  - [ ] Project configuration valid
- Status: pending

### Phase 2.2: 创建 Worktree
- Description: 创建 Git worktree 隔离开发
- Tool: pyflow-using-git-worktrees
- Tool Type: Skill
- Args: feature-branch-name
- CHECKLIST:
  - [ ] Git worktree created
  - [ ] Feature branch created
  - [ ] Working directory switched
- Status: pending

### Phase 4: TDD 执行
- Description: 完整 TDD 流程
- Tool: pyflow-tdd-cycle
- Tool Type: Skill
- Args: {{GOAL}}
- CHECKLIST:
  - [ ] Tests generated (RED)
  - [ ] All tests fail with meaningful errors (RED)
  - [ ] Compliance: Tests cover Constitution quality standards (RED)
  - [ ] All features implemented (GREEN)
  - [ ] All tests pass (GREEN)
  - [ ] Compliance: Code follows Constitution requirements (GREEN)
  - [ ] Code refactored (REFACTOR)
  - [ ] All tests still pass (REFACTOR)
  - [ ] Code quality improved (REFACTOR)
  - [ ] Compliance: Refactor preserves Constitution compliance (REFACTOR)
- Status: pending

### Phase 5: 质量审核
- Description: 基础验证
- Tool: bash
- Tool Type: Command
- Args: pytest tests/ -v && ruff check src/
- CHECKLIST:
  - [ ] All tests pass (100%)
  - [ ] Code style checks pass (ruff)
  - [ ] Ready for delivery
  - [ ] Compliance: Code follows Constitution standards
- Status: pending

---

**预计时间**: 30-60 分钟
**跳过的环节**: Phase 0 (brainstorming), Phase 1 (constitution), Phase 5.2 (code-reviewer)
