# Workflow Mapping

本文档详细说明三维参数到模板的完整映射关系。

---

## 完整映射表

### Python 模板（已实现）

| 编号 | 项目状态 | 复杂度 | 模板文件 | Phase 数量 | 预计时间 |
|------|---------|--------|----------|-----------|---------|
| 1 | new | simple | task_plan_new_simple.md | 3 | 30-60 分钟 |
| 2 | new | medium | task_plan_new_medium.md | 5 | 2-4 小时 |
| 3 | new | complex | task_plan_new_complex.md | 7 | 1-3 天 |
| 4 | add-feature | simple | task_plan_add_simple.md | 3 | 30-60 分钟 |
| 5 | add-feature | medium | task_plan_add_medium.md | 6 | 2-4 小时 |
| 6 | add-feature | complex | task_plan_add_complex.md | 8 | 1-3 天 |

### TypeScript 模板（预留）

未来实现时，创建以下文件：
- `templates/typescript/task_plan_new_simple.md`
- `templates/typescript/task_plan_new_medium.md`
- `templates/typescript/task_plan_new_complex.md`
- `templates/typescript/task_plan_add_simple.md`
- `templates/typescript/task_plan_add_medium.md`
- `templates/typescript/task_plan_add_complex.md`

### Go 模板（预留）

未来实现时，创建以下文件：
- `templates/go/task_plan_new_simple.md`
- `templates/go/task_plan_new_medium.md`
- `templates/go/task_plan_new_complex.md`
- `templates/go/task_plan_add_simple.md`
- `templates/go/task_plan_add_medium.md`
- `templates/go/task_plan_add_complex.md`

---

## Phase 差异对照表

### 新项目 vs 老项目

| Phase | 新-简单 | 新-中等 | 新-复杂 | 老-简单 | 老-中等 | 老-复杂 |
|-------|---------|---------|---------|---------|---------|---------|
| Phase 0 | ❌ 跳过 | ✅ 推荐 | ✅ ⭐ 必需 | ❌ 跳过 | ✅ 推荐 | ✅ ⭐ 必需 |
| Phase 1 | ✅ 精简 | ✅ 完整 | ✅ 完整+ADR | ❌ 跳过 | ✅ 检查 | ✅ 检查+更新 |
| Phase 2 | ✅ 精简+Git | ✅ 完整+Git | ✅ 完整+Git | ✅ 验证+Git | ✅ 验证+依赖+Git | ✅ 验证+依赖+Git |
| Phase 4 | pyflow-tdd-cycle | R→G→R | 多工具 | pyflow-tdd-cycle | R→G→R | 多工具 |
| Phase 5 | 基础验证 | 完整审核 | 深度审核 | 基础验证 | 完整审核+Git | 深度审核+Git |

**图例**:
- ⭐ **必需**: 必须执行
- ✅ **推荐**: 强烈建议执行
- 精简: 执行简化版本
- 完整: 执行完整流程
- 验证: 只验证不创建
- R→G→R: RED→GREEN→REFACTOR（分工具执行）
- pyflow-tdd-cycle: 自动调用 TDD skill（简单项目）
- 多工具: test-automator + python-pro + async-patterns + performance-opt

---

## 工具调用对照

### Phase 1: 项目规则

| 场景 | 工具 | 参数 |
|------|------|------|
| 新-简单 | pyflow-constitution | --simple |
| 新-中等 | pyflow-constitution | --medium |
| 新-复杂 | pyflow-constitution | --complex |
| 老-简单 | - | 跳过 |
| 老-中等 | pyflow-constitution | --check |
| 老-复杂 | pyflow-constitution | --update |

### Phase 2: 项目准备

**注意**: python-scaffold 已废弃，项目准备阶段需要手动完成或使用其他工具。

| 场景 | 工具 | 参数 |
|------|------|------|
| 新-简单 | 手动或 `uv init` | - |
| 新-中等 | 手动或 `uv init` | - |
| 新-复杂 | 手动或自定义脚本 | - |
| 老-简单 | bash | test -d .venv |
| 老-中等 | pyflow-uv-package-manager | add <deps> |
| 老-复杂 | pyflow-uv-package-manager | add <deps> |

**所有老项目都需要**: pyflow-using-git-worktrees

### Phase 4: TDD 执行

| 场景 | 工具组合 | 说明 |
|------|---------|------|
| 简单（新/老） | pyflow-tdd-cycle | 自动 TDD 流程 |
| 中等（新/老） | pyflow-test-automator → pyflow-python-pro | 分工具执行 |
| 复杂（新/老） | pyflow-test-automator → pyflow-python-pro → pyflow-async-python-patterns → pyflow-python-performance-optimization | 多工具组合（包含 2 个 skills）|

### Phase 5: 质量审核

| 场景 | 验证 | 审核 | Git |
|------|------|------|-----|
| 简单 | pytest + ruff | 跳过 | 不需要 |
| 中等 | pytest + mypy + ruff + coverage | pyflow-code-reviewer | ✅ 需要 |
| 复杂 | 完整 + 性能分析 | pyflow-code-reviewer + pyflow-security-auditor | ✅ 需要 |

---

## CHECKLIST 更新规则

每个 Phase 完成后，必须更新 CHECKLIST.md 对应的 checkbox。

### 更新时机

| Phase | CHECKLIST 项 |
|-------|-------------|
| Phase 0 | Requirements clarified, Design document created |
| Phase 1 | Constitution created/updated, Project-specific rules defined |
| Phase 2 | Project scaffold created, Git initialized, CHECKLIST.md created |
| Phase 4.1 | Tests generated (RED) |
| Phase 4.2 | All features implemented (GREEN), All tests pass |
| Phase 4.3 | Code refactored (REFACTOR), All tests still pass |
| Phase 5.1 | All tests pass, Coverage meets minimum, Code style checks pass |
| Phase 5.2 | Code review completed, Constitution compliance verified |
| Phase 5.3 | Security audit completed, Security best practices verified |
| Phase 5.4 | All changes committed, Feature branch merged |

### 更新方法

使用 **Edit 工具** 将 `[ ]` 替换为 `[x]`，并添加验证结果。

---

## 会话恢复流程

### 第一次会话

1. projectflow-planner 创建 task_plan.md
2. projectflow-executor 开始执行
3. 执行到一半会话中断

### 第二次会话

用户只需说："继续执行 task_plan.md"

projectflow-executor 会：
1. 读取 task_plan.md
2. 找到下一个 `pending` 的 Phase
3. 继续执行

### 检查点

每个 Phase 完成后更新：
- task_plan.md: 标记 Phase 为 `complete`
- progress.md: 记录执行结果
- CHECKLIST.md: 更新 checkbox

---

**文档版本**: 1.0.0
**最后更新**: 2026-02-11
