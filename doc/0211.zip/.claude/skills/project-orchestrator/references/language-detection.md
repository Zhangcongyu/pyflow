# 语言检测规则

本文档详细说明如何检测用户请求中的语言类型。

---

## 检测优先级

1. **显式提及** - 用户直接说出语言名称
2. **框架关键词** - 通过框架推断语言
3. **技术栈** - 通过技术栈推断语言
4. **文件扩展名** - 通过文件类型推断语言
5. **配置文件** - 通过项目配置文件推断语言

---

## Python 检测规则

### 显式提及
| 用户语言 | 检测结果 |
|---------|---------|
| "Python", "python", "py" | Python |
| "使用 Python 开发" | Python |

### 框架关键词
| 框架 | 语言 | 触发词 |
|------|------|--------|
| FastAPI | Python | fastapi, FastAPI |
| Django | Python | django, Django |
| Flask | Python | flask, Flask |
| Pyramid | Python | pyramid |
| Tornado | Python | tornado |
| Aiohttp | Python | aiohttp |

### 技术栈
| 技术 | 语言 | 触发词 |
|------|------|--------|
| SQLAlchemy | Python | sqlalchemy, SQLAlchemy |
| Pydantic | Python | pydantic, Pydantic |
| asyncio | Python | asyncio, async/await |
| Celery | Python | celery |
| Poetry | Python | poetry |
| uv | Python | uv, uvicorn |

### 文件扩展名
| 扩展名 | 语言 |
|--------|------|
| `.py` | Python |
| `.pyx` | Cython (Python) |
| `.pyi` | Python stub |

### 配置文件
| 文件名 | 语言 |
|--------|------|
| `pyproject.toml` | Python |
| `requirements.txt` | Python |
| `setup.py` | Python |
| `Pipfile` | Python |
| `poetry.lock` | Python |
| `.python-version` | Python |

---

## TypeScript/JavaScript 检测规则

### 显式提及
| 用户语言 | 检测结果 |
|---------|---------|
| "TypeScript", "typescript", "ts" | TypeScript |
| "JavaScript", "javascript", "js" | JavaScript |
| "Node.js", "node" | Node.js (JS/TS) |

### 框架关键词
| 框架 | 语言 | 触发词 |
|------|------|--------|
| Express | JavaScript/TypeScript | express, Express |
| NestJS | TypeScript | nestjs, NestJS |
| Next.js | TypeScript/JavaScript | nextjs, Next.js |
| React | TypeScript/JavaScript | react, React |
| Vue | TypeScript/JavaScript | vue, Vue |
| Angular | TypeScript | angular, Angular |
| Svelte | TypeScript/JavaScript | svelte |

### 技术栈
| 技术 | 语言 | 触发词 |
|------|------|--------|
| npm/yarn/pnpm | JavaScript/TypeScript | npm, yarn, pnpm |
| webpack/vite | JavaScript/TypeScript | webpack, vite |
| ts-node | TypeScript | ts-node |
| tsx | TypeScript | tsx |

### 文件扩展名
| 扩展名 | 语言 |
|--------|------|
| `.ts` | TypeScript |
| `.tsx` | TypeScript (React) |
| `.js` | JavaScript |
| `.jsx` | JavaScript (React) |
| `.mjs` | JavaScript (ESM) |

### 配置文件
| 文件名 | 语言 |
|--------|------|
| `package.json` | JavaScript/TypeScript |
| `tsconfig.json` | TypeScript |
| `jsconfig.json` | JavaScript |
| `yarn.lock` | JavaScript/TypeScript |
| `package-lock.json` | JavaScript/TypeScript |

---

## Go 检测规则

### 显式提及
| 用户语言 | 检测结果 |
|---------|---------|
| "Go", "go", "Golang", "golang" | Go |

### 框架关键词
| 框架 | 语言 | 触发词 |
|------|------|--------|
| Gin | Go | gin, Gin |
| Echo | Go | echo, Echo |
| Fiber | Go | fiber, Fiber |
| Gorm | Go | gorm, GORM |
| Buffalo | Go | buffalo |

### 技术栈
| 技术 | 语言 | 触发词 |
|------|------|--------|
| go.mod | Go | go.mod |
| go.sum | Go | go.sum |
| goroutine | Go | goroutine |
| channel | Go | channel |

### 文件扩展名
| 扩展名 | 语言 |
|--------|------|
| `.go` | Go |

### 配置文件
| 文件名 | 语言 |
|--------|------|
| `go.mod` | Go |
| `go.sum` | Go |
| `Gopkg.toml` | Go |
| `Godeps/Godeps.json` | Go |

---

## Rust 检测规则

### 显式提及
| 用户语言 | 检测结果 |
|---------|---------|
| "Rust", "rust" | Rust |

### 框架关键词
| 框架 | 语言 | 触发词 |
|------|------|--------|
| Actix | Rust | actix, Actix |
| Rocket | Rust | rocket, Rocket |
| Tokio | Rust | tokio, Tokio |

### 技术栈
| 技术 | 语言 | 触发词 |
|------|------|--------|
| Cargo | Rust | cargo, Cargo |
| Crates.io | Rust | crates |

### 文件扩展名
| 扩展名 | 语言 |
|--------|------|
| `.rs` | Rust |

### 配置文件
| 文件名 | 语言 |
|--------|------|
| `Cargo.toml` | Rust |
| `Cargo.lock` | Rust |

---

## 检测逻辑

### 伪代码

```python
def detect_language(user_request, directory_context):
    # 1. 检查显式提及
    for language, keywords in EXPLICIT_MENTIONS.items():
        if keyword in user_request.lower():
            return language

    # 2. 检查框架关键词
    for framework, language in FRAMEWORK_KEYWORDS.items():
        if framework.lower() in user_request.lower():
            return language

    # 3. 检查配置文件
    for file, language in CONFIG_FILES.items():
        if file_exists(directory_context, file):
            return language

    # 4. 检查文件扩展名
    for ext, language in FILE_EXTENSIONS.items():
        if has_files_with_extension(directory_context, ext):
            return language

    # 5. 无法确定
    return UNKNOWN
```

---

## 模糊情况处理

### 多语言候选

当检测到多个可能的语言时，优先级：

1. **TypeScript > JavaScript** - TypeScript 更现代
2. **显式提及 > 框架推断** - 用户说算数
3. **配置文件 > 文件扩展名** - 配置更明确

### 询问用户

如果无法确定，使用以下格式询问：

```
检测到多种可能的语言:
1. Python (FastAPI)
2. TypeScript (Express)

请问您想使用哪种语言开发？
```

---

## 示例

### 示例 1: 明确的 Python 请求

**用户请求**: "创建一个 FastAPI 项目"

**检测过程**:
1. 显式提及: 无
2. 框架关键词: "FastAPI" → Python
3. **结果**: Python

### 示例 2: TypeScript 推断

**用户请求**: "创建一个 NestJS API"

**检测过程**:
1. 显式提及: 无
2. 框架关键词: "NestJS" → TypeScript
3. **结果**: TypeScript

### 示例 3: 通过配置文件检测

**用户请求**: "在现有项目添加新功能"

**目录扫描**:
- 发现 `package.json` 和 `tsconfig.json`
- **结果**: TypeScript

### 示例 4: 模糊情况

**用户请求**: "创建一个 web API"

**检测过程**:
1. 无显式提及
2. 无框架关键词
3. 无配置文件（新项目）
4. **结果**: 询问用户

---

**文档创建时间**: 2026-02-09
**用途**: 语言检测规则
