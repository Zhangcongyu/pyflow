# 项目脚手架创建指南

**用途**: Phase 2 项目准备的详细执行指南

---

## 🎯 核心逻辑

1. **检查项目架构是否存在**
2. **如果不存在** → 按照项目类型创建完整脚手架
3. **如果已存在** → 检查并补齐缺失部分

---

## 📋 输入和参考

### 必须使用的结果

**Phase 0: 需求分析**（设计文档）
- 项目类型（FastAPI/Django/CLI/Library 等）
- 目录结构（如果定义了）
- 技术约束（Python 版本、依赖版本等）
- 功能需求

**Phase 1: 项目规则**（Constitution）
- 项目特定的编码标准
- 命名约定
- 架构原则
- 技术选型约束

---

## 📁 新项目：创建脚手架

### 步骤 1: 确定目录结构

**决策逻辑**（优先级）：

1. ✅ **查看需求文档**（如果存在）
   - 读取 `./pjflow/requirements.md`
   - 查找架构设计部分
   - 如果定义了目录结构，使用该结构

2. ✅ **参考 project-archetypes.md**（如果需求文档未定义）
   - 读取 `references/project-archetypes.md`
   - 根据项目类型（FastAPI/Django/CLI/Library 等）选择对应模板
   - 使用模板定义的目录结构

**执行方法**：

```python
# 优先使用需求文档中的架构设计
if exists("./pjflow/requirements.md"):
    requirements = Read("./pjflow/requirements.md")
    # 从需求文档中提取目录结构
    # 根据定义的目录结构创建目录和空文件
else:
    # 参考 project-archetypes.md 中的项目类型模板
    archetypes = Read("references/project-archetypes.md")
    # 根据项目类型选择对应模板
    # 使用模板定义的目录结构创建目录和空文件
```

### 步骤 2: 创建目录和空文件

根据确定的目录结构，使用 **Write 工具**：
- 创建所有目录
- 创建所有 `__init__.py` 文件（空内容）
- 创建所有编码文件（空文件，不编写业务逻辑）

### 步骤 3: 编写系统文件

结合以下输入编写 `pyproject.toml`:
- **project-archetypes.md 中的模板**（根据项目类型选择）
- **Phase 1 Constitution**（`./pjflow/constitution.md`）- 项目特定的技术要求和约束

编写其他系统文件（使用 project-archetypes.md 中的通用模板）：
- `.gitignore` - Python 通用配置
- `Makefile` - 常用命令快捷方式
- `README.md` - 项目说明（基于 Phase 0 需求）
- `.env.example` - 环境变量示例

#### 步骤 3: 创建虚拟环境并安装依赖

调用 `pyflow-uv-package-manager`:
- 创建虚拟环境
- 根据 `pyproject.toml` 安装依赖

#### 步骤 4: 初始化 Git

```bash
git init
git add .
git commit -m "feat: initialize project scaffold"
```

#### 步骤 5: 验证脚手架

```bash
# 检查目录结构
tree -L 3

# 检查依赖安装
source .venv/bin/activate && pip list

# 检查 Git
git status
```

---

## 📁 老项目：检查并补齐

### 检查清单

```bash
# 检查虚拟环境
test -d .venv || echo "❌ 虚拟环境缺失"

# 检查项目结构
test -d src || echo "❌ src 目录缺失"

# 检查 Constitution
test -f ./pjflow/constitution.md || echo "❌ Constitution 缺失"
```

### 补齐缺失部分

1. **缺失目录** → 创建
2. **缺失系统文件** → 编写
3. **缺失依赖** → 调用 `pyflow-uv-package-manager` 安装
4. **缺失 Constitution** → 调用 `pyflow-constitution` 创建

---

## 🌏 中国国内环境

### 配置

**pyproject.toml**:
```toml
[[tool.uv.index]]
name = "tsinghua"
url = "https://pypi.tuna.tsinghua.edu.cn/simple"
default = true
```

---

**文档版本**: 1.0.0
**创建时间**: 2026-02-11
**用途**: Phase 2 项目准备详细指南
