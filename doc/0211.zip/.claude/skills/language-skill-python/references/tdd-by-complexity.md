# Phase 4 TDD 按复杂度差异化

本文档详细说明 Phase 4 在不同复杂度下的 TDD 执行差异。

---

## 概述

Phase 4 是 TDD 执行的核心阶段，根据**复杂度**选择不同的工具组合：

| 复杂度 | 工具组合 | 适用场景 |
|--------|---------|---------|
| **简单** | tdd-cycle | 新-简单、老-简单 |
| **中等** | test-automator → python-pro → python-pro | 新-中等、老-中等 |
| **复杂** | test-automator → python-pro + async-patterns → performance-opt + python-pro | 新-复杂、老-复杂 |

---

## 工具调用指南

### Task 工具调用（用于 Agents）

**🚨 参数顺序至关重要！**

```python
Task(
    subagent_type="<agent-name>",      # 1. 必须在第一位
    subject="<简短标题>",                # 2. 必需 (imperative form)
    description="<详细描述>",            # 3. 必需
    activeForm="<正在进行时>",           # 4. 必需
    prompt="<完整上下文>"                # 5. 必需
)
```

**常见错误对照**:

| ❌ 错误 | ✅ 正确 | 说明 |
|------|------|------|
| `description="..."` 在第一位 | `subagent_type="..."` 在第一位 | 参数顺序重要 |
| 无 `subject` | `subject="..."` (必需) | 必须有 subject |
| 无 `activeForm` | `activeForm="..."` (必需) | 必须有 activeForm |
| 凭记忆调用 | 参考下方示例 | 必须遵守格式 |

**参考**: SKILL-IMPROVEMENT-PROPOSAL.md (ERROR-002 解决方案)

---

### Skill 工具调用（用于 Skills）

```python
Skill(
    skill="<skill-name>",
    args="<参数>"
)
```

**使用场景**:
- 调用 skill（如 `tdd-cycle`, `speckit.constitution`）
- 简单调用，不需要复杂的参数结构

---

## 简单项目 - 使用 tdd-cycle

**适用场景**:
- 新-简单项目
- 老-简单项目

**工具**: `tdd-cycle`

### 完整流程

#### RED Phase

**使用 Skill 工具调用**: `tdd-cycle`

**传入**:
- 任务描述
- "RED 阶段：编写失败测试"

**要求**:
- 使用 pytest
- 测试应该失败（功能未实现）
- 包含基本场景

**验证**: 测试文件已生成，运行 `pytest` 确认失败

#### GREEN Phase

**使用 Skill 工具调用**: `tdd-cycle`

**传入**:
- 失败的测试
- 任务描述
- "GREEN 阶段：实现功能"

**要求**:
- 让测试通过
- 遵循最佳实践
- 简单实现

**验证**: `pytest` 所有测试通过

#### REFACTOR Phase

**使用 Skill 工具调用**: `tdd-cycle`

**传入**:
- 通过的测试
- 当前代码
- "REFACTOR 阶段：优化代码"

**要求**:
- 提高可读性
- 消除重复
- 保持测试通过

**验证**: `pytest` 测试仍然通过，`ruff` 检查通过

### 特点

- **单一工具**: 整个 TDD 循环使用同一个 skill
- **简化流程**: 不需要切换不同的 agent
- **适合快速**: 简单项目不需要复杂的工具链

---

## 中等项目 - 分工具执行

**适用场景**:
- 新-中等项目
- 老-中等项目

**工具组合**: test-automator → python-pro → python-pro

### RED Phase - test-automator

**使用 Task 工具调用**: `unit-testing:test-automator`

**传入参数**:
```python
Task(
    subagent_type="unit-testing:test-automator",
    subject="Generate tests for <feature>",
    prompt="""
请生成 <feature> 的测试套件（RED phase）。

**项目位置**: <path>
**需要测试的功能**: <feature list>

**要求**:
- 使用 pytest
- 测试应该失败（功能未实现）
- 包含边界情况

不要实现任何功能代码。
""",
)
```

**验证**:
```bash
pytest tests/test_<feature>.py -v
# 预期: 大部分测试失败（RED）
```

### GREEN Phase - python-pro

**使用 Task 工具调用**: `python-development:python-pro`

**传入参数**:
```python
Task(
    subagent_type="python-development:python-pro",
    subject="Implement <feature> (GREEN phase)",
    prompt="""
请实现 <feature> 使测试通过（GREEN phase）。

**项目位置**: <path>
**测试文件**: <test file>

**重要约束**:
- 使用 SQLAlchemy 2.0 async API
- 遵循 constitution.md
- 类型注解完整

**验收标准**:
- 所有测试通过
- 代码符合 FastAPI best practices
""",
)
```

**验证**:
```bash
pytest tests/test_<feature>.py -v
# 预期: 所有测试通过（GREEN）
```

### REFACTOR Phase - python-pro

**使用 Task 工具调用**: `python-development:python-pro`

**传入参数**:
```python
Task(
    subagent_type="python-development:python-pro",
    subject="Refactor <feature> (REFACTOR phase)",
    prompt="""
请重构 <feature> 实现代码（REFACTOR phase）。

**项目位置**: <path>
**当前状态**: 测试已通过

**重构目标**:
- 消除重复代码
- 优化性能
- 提高可读性

**重要约束**:
- 所有测试必须继续通过
- 不能改变 API 接口
""",
)
```

**验证**:
```bash
# 测试仍然通过
pytest tests/test_<feature>.py -v

# 代码检查通过
ruff check src/
```

---

## 复杂项目 - 多工具组合

**适用场景**:
- 新-复杂项目
- 老-复杂项目

**工具组合**:
- RED: test-automator
- GREEN: python-pro + async-python-patterns (+ 性能优化)
- REFACTOR: performance-optimization + python-pro

### RED Phase - test-automator

**使用 Task 工具调用**: `unit-testing:test-automator`

**传入参数**: 同中等项目

**验证**: 同中等项目

### GREEN Phase - 多步执行

#### 步骤 1: 基础实现

**使用 Task 工具调用**: `python-development:python-pro`

**传入参数**:
```python
Task(
    subagent_type="python-development:python-pro",
    subject="Implement <feature> (GREEN phase - Step 1)",
    prompt="""
请实现 <feature> 使测试通过（GREEN phase - 基础实现）。

**项目位置**: <path>
**测试文件**: <test file>

**重要约束**:
- 基础实现：让测试通过
- 使用 SQLAlchemy 2.0 async API
- 类型注解完整

**验收标准**:
- 所有测试通过
""",
)
```

#### 步骤 2: 异步优化（如果需要）

**使用 Skill 工具调用**: `python-development:async-python-patterns`

**传入参数**:
```python
Skill(
    skill="python-development:async-python-patterns",
    args="""
请优化 <feature> 的异步处理（GREEN phase - 异步优化）。

**项目位置**: <path>
**当前代码**: <current implementation>

**优化目标**:
- 提高并发性能
- 优化 async/await 使用
- 减少阻塞

**要求**:
- 保持所有测试通过
- 不能改变 API 接口
""",
)
```

**验证**:
```bash
pytest tests/test_<feature>.py -v
# 测试仍然通过
```

#### 步骤 3: 额外优化（根据需求）

**使用 Skill 工具调用**: `python-development:python-performance-optimization`

**传入参数**:
```python
Skill(
    skill="python-development:python-performance-optimization",
    args="""
请优化 <feature> 的性能（GREEN phase - 性能优化）。

**项目位置**: <path>
**当前代码**: <current implementation>

**优化目标**:
- 减少内存占用
- 优化数据库查询
- 提高响应速度

**要求**:
- 保持所有测试通过
- 不能改变 API 接口
""",
)
```

**验证**:
```bash
pytest tests/test_<feature>.py -v
# 测试仍然通过
# 可选：运行性能分析
```

### REFACTOR Phase - 多步执行

#### 步骤 1: 性能优化

**使用 Skill 工具调用**: `python-development:python-performance-optimization`

**传入参数**:
```python
Skill(
    skill="python-development:python-performance-optimization",
    args="""
请深入优化 <feature> 的性能（REFACTOR phase - 性能优化）。

**项目位置**: <path>
**当前状态**: 测试已通过，功能已实现

**优化目标**:
- 深入性能优化
- 减少内存占用
- 优化算法复杂度

**重要约束**:
- 所有测试必须继续通过
- 不能改变 API 接口
""",
)
```

**验证**:
```bash
pytest tests/test_<feature>.py -v
# 测试仍然通过
```

#### 步骤 2: 最终清理

**使用 Task 工具调用**: `python-development:python-pro`

**传入参数**:
```python
Task(
    subagent_type="python-development:python-pro",
    subject="Final refactor and cleanup (REFACTOR phase - Step 2)",
    prompt="""
请对 <feature> 进行最终重构和清理（REFACTOR phase - 最终清理）。

**项目位置**: <path>
**当前状态**: 性能优化已完成

**重构目标**:
- 代码组织和可读性
- 添加必要的文档
- 最终的代码清理

**重要约束**:
- 所有测试必须继续通过
- 不能改变 API 接口
- 保持性能优化的效果
""",
)
```

**验证**:
```bash
# 测试
pytest tests/test_<feature>.py -v

# 代码质量
ruff check src/

# 性能（如果做了性能优化）
# 可以运行性能分析工具验证
```

---

## 工具选择决策树

```
Phase 4: TDD 执行
  ↓
接收参数: --simple / --medium / --complex
  ↓
┌─────────────────────────────────┐
│ --simple?                        │
│ YES → 使用 tdd-cycle            │
│    ├─ RED: tdd-workflows        │
│    ├─ GREEN: tdd-workflows      │
│    └─ REFACTOR: tdd-workflows  │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ --medium?                        │
│ YES → 分工具执行                │
│    ├─ RED: test-automator       │
│    ├─ GREEN: python-pro         │
│    └─ REFACTOR: python-pro     │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ --complex?                       │
│ YES → 多工具组合                │
│    ├─ RED: test-automator       │
│    ├─ GREEN (步骤1): python-pro │
│    ├─ GREEN (步骤2): async-patterns │
│    ├─ GREEN (步骤3): performance-opt │
│    ├─ REFACTOR (步骤1): performance-opt │
│    └─ REFACTOR (步骤2): python-pro │
└─────────────────────────────────┘
```

---

## 快速参考卡

### 简单项目

```
Phase 4: 使用 tdd-cycle
├─ RED: 编写失败测试
├─ GREEN: 实现功能
└─ REFACTOR: 优化代码
```

### 中等项目

```
Phase 4: 分工具执行
├─ RED: unit-testing:test-automator
├─ GREEN: python-development:python-pro
└─ REFACTOR: python-development:python-pro
```

### 复杂项目

```
Phase 4: 多工具组合
├─ RED: unit-testing:test-automator
├─ GREEN (步骤 1): python-development:python-pro
├─ GREEN (步骤 2): python-development:async-python-patterns
├─ GREEN (步骤 3): python-development:python-performance-optimization
├─ REFACTOR (步骤 1): python-development:python-performance-optimization
└─ REFACTOR (步骤 2): python-development:python-pro
```

---

## 验证命令汇总

### 所有复杂度都需要

```bash
# 运行测试
pytest tests/ -v

# 代码检查
ruff check src/
```

### 中等及以上需要

```bash
# 覆盖率
pytest --cov=src --cov-report=term-missing

# 类型检查
mypy src/
```

### 复杂项目额外需要

```bash
# 性能分析（可选）
# python -m cProfile -o profile.stats

# 安全扫描
# bandit -r src/
```

---

## 总结对比表

| 阶段 | 简单 | 中等 | 复杂 |
|------|------|------|------|
| **工具** | 单一 skill | 3 个工具 | 6 次工具调用 |
| **步骤** | 3 步 | 3 步 | 6 步 |
| **时间** | 最短 | 中等 | 最长 |
| **优化** | 基础重构 | 基础重构 | 性能优化 + 重构 |
| **审核** | 基础验证 | 完整审核 | 深度审核 |

---

**文档创建时间**: 2026-02-09
**用途**: Phase 4 TDD 按复杂度差异化说明
