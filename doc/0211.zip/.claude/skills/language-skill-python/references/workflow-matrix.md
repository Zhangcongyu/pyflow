# 6 种场景完整流程对照表

本文档详细说明 6 种场景（新/老项目 × 简单/中等/复杂）的完整执行流程。

---

## 场景 1: 新-简单

**适用**: 单一脚本、小工具、明确需求

**参数**: `--new --simple`

### 完整流程

| Phase | 执行 | 工具 | 输出 |
|-------|------|------|------|
| **Phase 0** | 可选（需求明确时跳过） | - | - |
| **Phase 1** | 精简 constitution | `speckit.constitution` | `.specify/memory/constitution.md` |
| **Phase 2** | 精简脚手架（含 git init） | `python-development:python-scaffold` | `src/`, `tests/`, `.git/` |
| **Phase 4** | tdd-cycle | `tdd-cycle` | 功能代码 |
| **Phase 5** | 基础验证 | Bash (pytest + ruff) | 测试通过 |

**预计时间**: 30-60 分钟

**跳过的环节**:
- Phase 0: brainstorming（需求明确）
- Phase 5.2: code-reviewer（跳过）

---

## 场景 2: 新-中等

**适用**: FastAPI CRUD、数据处理 service

**参数**: `--new --medium`

### 完整流程

| Phase | 执行 | 工具 | 输出 |
|-------|------|------|------|
| **Phase 0** | 推荐 | `superpowers:brainstorming` | design.md |
| **Phase 1** | 完整 constitution | `speckit.constitution` | constitution.md |
| **Phase 2** | 完整脚手架（含 git init） | `python-development:python-scaffold` | 完整项目结构 + `.git/` |
| **Phase 4 RED** | 生成测试 | `unit-testing:test-automator` | 测试文件 |
| **Phase 4 GREEN** | 实现功能 | `python-development:python-pro` | 功能代码 |
| **Phase 4 REFACTOR** | 重构 | `python-development:python-pro` | 优化代码 |
| **Phase 5.1** | 质量门控 | Bash (pytest + mypy + ruff) | 验证通过 |
| **Phase 5.2** | 代码审核 | `comprehensive-review:code-reviewer` | 审查报告 |

**预计时间**: 2-4 小时

---

## 场景 3: 新-复杂

**适用**: 完整系统、多模块、高性能要求

**参数**: `--new --complex`

### 完整流程

| Phase | 执行 | 工具 | 输出 |
|-------|------|------|------|
| **Phase 0** | ⭐ 必需 | `superpowers:brainstorming` | design.md |
| **Phase 1** | 完整+ADR | `speckit.constitution` | constitution.md + ADR |
| **Phase 2** | 完整脚手架（含 git init） | `python-development:python-scaffold` | 完整结构 + 多模块 + `.git/` |
| **Phase 4 RED** | 生成测试 | `unit-testing:test-automator` | 测试文件 |
| **Phase 4 GREEN** | 基础实现 | `python-development:python-pro` | 基础代码 |
| **Phase 4 GREEN** | 异步优化 | `python-development:async-python-patterns` | 异步代码 |
| **Phase 4 GREEN** | 性能优化 | `python-development:python-performance-optimization` | 优化代码 |
| **Phase 4 REFACTOR** | 性能优化 | `python-development:python-performance-optimization` | 性能优化 |
| **Phase 4 REFACTOR** | 最终清理 | `python-development:python-pro` | 最终代码 |
| **Phase 5.1** | 深度验证 | Bash (完整 + 性能分析) | 验证通过 |
| **Phase 5.2** | 完整审核 | `code-reviewer` + `security-auditor` | 审查报告 |

**预计时间**: 1-3 天

**Git 状态**: 已在主支（main/master）开发，无需额外 Git 操作

---

## 场景 4: 老-简单

**适用**: 在现有项目添加简单功能

**参数**: `--add-feature --simple`

### 完整流程

| Phase | 执行 | 工具 | 输出 |
|-------|------|------|------|
| **Phase 0** | 跳过 | - | - |
| **Phase 1** | 跳过 | - | - |
| **Phase 2.1** | 基础验证 | Bash (test -d .venv) | 环境验证 |
| **Phase 2.2** | 创建 worktree | `superpowers:using-git-worktrees` | worktree |
| **Phase 4** | tdd-cycle | `tdd-cycle` | 功能代码 |
| **Phase 5** | 基础验证 | Bash (pytest + ruff) | 测试通过 |

**预计时间**: 30-60 分钟

**跳过的环节**:
- Phase 0: brainstorming
- Phase 1: constitution
- Phase 5.2: code-reviewer

---

## 场景 5: 老-中等

**适用**: 在现有项目添加中等复杂功能

**参数**: `--add-feature --medium`

### 完整流程

| Phase | 执行 | 工具 | 输出 |
|-------|------|------|------|
| **Phase 0** | 推荐 | `superpowers:brainstorming` | design.md |
| **Phase 1** | 检查 | `speckit.constitution` | constitution.md（可能更新） |
| **Phase 2.1** | 标准验证 | Bash (test -d .venv) | 环境验证 |
| **Phase 2.2** | 添加依赖 | `python-development:uv-package-manager` | 新依赖 |
| **Phase 2.3** | 创建 worktree | `superpowers:using-git-worktrees` | worktree |
| **Phase 4 RED** | 生成测试 | `unit-testing:test-automator` | 测试文件 |
| **Phase 4 GREEN** | 实现功能 | `python-development:python-pro` | 功能代码 |
| **Phase 4 REFACTOR** | 重构 | `python-development:python-pro` | 优化代码 |
| **Phase 5.1** | 质量门控 | Bash (pytest + mypy + ruff) | 验证通过 |
| **Phase 5.2** | 代码审核 | `comprehensive-review:code-reviewer` | 审查报告 |
| **Phase 5.3** | Git 完成 | `superpowers:finishing-a-development-branch` | 合并/保留/PR |

**预计时间**: 2-4 小时

---

## 场景 6: 老-复杂

**适用**: 在现有项目添加复杂功能

**参数**: `--add-feature --complex`

### 完整流程

| Phase | 执行 | 工具 | 输出 |
|-------|------|------|------|
| **Phase 0** | ⭐ 必需 | `superpowers:brainstorming` | design.md |
| **Phase 1** | 检查+更新 | `speckit.constitution` | constitution.md（更新） |
| **Phase 2.1** | 深度验证 | Bash (完整验证) | 环境验证 |
| **Phase 2.2** | 添加依赖 | `python-development:uv-package-manager` | 新依赖 |
| **Phase 2.3** | 创建 worktree | `superpowers:using-git-worktrees` | worktree |
| **Phase 4 RED** | 生成测试 | `unit-testing:test-automator` | 测试文件 |
| **Phase 4 GREEN** | 基础实现 | `python-development:python-pro` | 基础代码 |
| **Phase 4 GREEN** | 异步优化 | `python-development:async-python-patterns` | 异步代码 |
| **Phase 4 GREEN** | 性能优化 | `python-development:python-performance-optimization` | 优化代码 |
| **Phase 4 REFACTOR** | 性能优化 | `python-development:python-performance-optimization` | 性能优化 |
| **Phase 4 REFACTOR** | 最终清理 | `python-development:python-pro` | 最终代码 |
| **Phase 5.1** | 深度验证 | Bash (完整 + 性能分析) | 验证通过 |
| **Phase 5.2** | 完整审核 | `code-reviewer` + `security-auditor` | 审查报告 |
| **Phase 5.3** | Git 完成 | `superpowers:finishing-a-development-branch` | 合并/保留/PR |

**预计时间**: 1-3 天

---

## 快速参考表

| 场景 | Phase 0 | Phase 1 | Phase 2 | Phase 4 | Phase 5 |
|------|---------|---------|---------|---------|---------|
| **新-简单** | 跳过 | 精简 | 精简+Git | tdd-cycle | 基础验证 |
| **新-中等** | 推荐 | 完整 | 完整+Git | R→G→R | 完整审核 |
| **新-复杂** | ⭐ 必需 | 完整+ADR | 完整+Git | 多工具 | 深度审核 |
| **老-简单** | 跳过 | 跳过 | 验证+Git | tdd-cycle | 基础验证 |
| **老-中等** | 推荐 | 检查 | 验证+依赖+Git | R→G→R | 完整审核 |
| **老-复杂** | ⭐ 必需 | 检查+更新 | 验证+依赖+Git | 多工具 | 深度审核 |

**图例**:
- ⭐ **必需**: 必须执行
- **推荐**: 强烈建议执行
- 可选: 根据情况决定
- 跳过: 不执行
- 完整: 执行完整流程
- 精简: 执行简化版本
- 验证: 只验证不创建
- R→G→R: RED→GREEN→REFACTOR (分工具执行)
- tdd-cycle: 使用 tdd-cycle skill
- 多工具: test-automator + python-pro + async-patterns + performance-opt

---

## 工具调用序列

### 简单项目 (新-简单, 老-简单)

```
tdd-cycle
  ├─ RED (编写失败测试)
  ├─ GREEN (实现功能)
  └─ REFACTOR (优化代码)
```

### 中等项目 (新-中等, 老-中等)

```
Phase 0 (可选): superpowers:brainstorming
Phase 1: speckit.constitution
Phase 2: python-scaffold / uv-package-manager
Phase 2: superpowers:using-git-worktrees
Phase 4:
  ├─ RED: unit-testing:test-automator
  ├─ GREEN: python-development:python-pro
  └─ REFACTOR: python-development:python-pro
Phase 5:
  ├─ 验证: pytest + mypy + ruff
  ├─ 审核: comprehensive-review:code-reviewer
  └─ Git: superpowers:finishing-a-development-branch
```

### 复杂项目 (新-复杂, 老-复杂)

```
Phase 0 ⭐: superpowers:brainstorming
Phase 1: speckit.constitution (+ ADR)
Phase 2: python-scaffold / uv-package-manager
Phase 2: superpowers:using-git-worktrees
Phase 4:
  ├─ RED: unit-testing:test-automator
  ├─ GREEN (步骤 1): python-development:python-pro
  ├─ GREEN (步骤 2): python-development:async-python-patterns
  ├─ GREEN (步骤 3): python-development:python-performance-optimization
  ├─ REFACTOR (步骤 1): python-development:python-performance-optimization
  └─ REFACTOR (步骤 2): python-development:python-pro
Phase 5:
  ├─ 验证: pytest + mypy + ruff + 性能分析
  ├─ 审核: code-reviewer + security-auditor
  └─ Git: superpowers:finishing-a-development-branch
```

---

**文档创建时间**: 2026-02-10
**更新时间**: 2026-02-10
**用途**: 6 种场景完整流程
**说明**: 已删除 Phase 3（planning-with-files 工具已废弃）
