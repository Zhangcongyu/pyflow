# Project Checklist

**Project Name**: {project_name}
**Project Type**: {FastAPI / CLI / Library / Django / Async}
**Complexity**: {Simple / Medium / Complex}
**Date Started**: {date}
**Date Completed**: {pending}

---

## Phase 0: 需求分析

### Completion Status

- [ ] Requirements clarified
- [ ] Design decisions documented
- [ ] Feature scope defined
- [ ] Technical constraints identified

### Verification Results

```bash
# Design document created
Output: {design_doc_path}

# Key requirements identified
- {requirement_1}
- {requirement_2}
- {requirement_3}
```

### Notes

_– Skill: 使用 `superpowers:brainstorming` 完成需求收集_
_– 用户选择: {user_choices}_

---

## Phase 1: 项目规则

### Completion Status

- [ ] Constitution created/updated
- [ ] Project-specific rules defined
- [ ] Coding standards established
- [ ] Technical constraints documented

### Verification Results

```bash
# Constitution file
Output: .specify/memory/constitution.md
Version: {version}

# Custom principles added
- Principle {N}: {principle_title}
```

### Notes

_– Skill: 使用 `speckit.constitution` 设置项目规则_
_– 定制化内容: {customizations}_

---

## Phase 2: 项目准备

### Completion Status

- [ ] Project scaffold created
- [ ] Directory structure initialized
- [ ] System files created (pyproject.toml, .gitignore, Makefile, etc.)
- [ ] Dependencies installed
- [ ] Git repository initialized
- [ ] Initial commit created
- [ ] CHECKLIST.md created from template

### Verification Results

```bash
# Directory structure
{project_name}/
├── src/{project_name}/
├── tests/
├── pyproject.toml
├── .gitignore
└── CHECKLIST.md ✅

# Dependencies installed
Total packages: {package_count}
Core: {core_count}
Dev: {dev_count}

# Git status
Branch: {branch_name}
Commits: 1 initial commit
```

### Notes

_– Skill: 根据项目类型创建脚手架（参考 project-archetypes.md）_
_– Skill: 使用 `uv-package-manager` 安装依赖_
_– Skill: 复制 checklist-template.md 到 CHECKLIST.md_

---

## Phase 4: TDD 执行 ⭐ 核心

### 4.1 RED Phase

#### Completion Status

- [ ] Phase 0 design document read and understood
- [ ] Constitution read and understood
- [ ] Tests generated
- [ ] All tests fail with meaningful errors
- [ ] Test failures indicate missing implementation
- [ ] No test passes accidentally
- [ ] Test naming follows Constitution conventions
- [ ] Test structure follows Constitution architecture principles
- [ ] Tests cover all Phase 0 requirements

#### Verification Results

```bash
# Test generation
pytest tests/ -v

Result: {test_count} tests failed ✅ (expected)

# Error breakdown
ImportError: {count} (missing implementation)
AttributeError: {count} (missing functions)
{other_errors}: {count}

# Test files created
{test_file_list}
```

#### 需求合规性（Phase 0）

- [ ] 已阅读 Phase 0 设计文档
- [ ] 理解所有功能需求
- [ ] 理解所有 API 规格
- [ ] 理解数据模型定义
- [ ] 测试覆盖所有需求

#### Constitution 合规性（Phase 1）

- [ ] 已阅读 Constitution
- [ ] 测试命名遵循 Constitution 命名约定
- [ ] 测试结构符合 Constitution 架构原则
- [ ] 测试覆盖 Constitution 定义的质量标准

#### Notes

_– Skill: 调用 `unit-testing:test-automator`_
_– Subject: "生成 {feature} 的测试套件（RED phase）"_
_– 自动验证: 所有测试失败（RED 状态确认）_

---

### 4.2 GREEN Phase

#### Completion Status

- [ ] Phase 0 requirements followed
- [ ] Constitution requirements followed
- [ ] All features implemented
- [ ] All tests pass
- [ ] Code coverage meets threshold
- [ ] No extra code beyond test requirements
- [ ] Type annotations complete per Constitution
- [ ] Code follows project constitution
- [ ] Architecture follows Constitution principles
- [ ] All technical constraints satisfied
- [ ] Implementation matches Phase 0 specifications

#### Verification Results

```bash
# Test results
pytest tests/ -v

Result: {passed_count} / {total_count} tests passed ✅ (100%)

# Coverage report
pytest --cov=src --cov-report=term-missing

Name                      Stmts   Miss  Cover   Missing
-------------------------------------------------------
{module_1}                {stmts}   {miss}  {cov}%
{module_2}                {stmts}   {miss}  {cov}%
-------------------------------------------------------
TOTAL                     {total}   {miss}  {coverage}%

# Code style
ruff check src/

Result: {ruff_errors} errors, {ruff_warnings} warnings

# Type checking (if applicable)
mypy src/

Result: {mypy_errors} errors
```

#### 需求合规性（Phase 0）

- [ ] 实现符合 Phase 0 功能需求
- [ ] API 端点符合设计文档规格
- [ ] 数据模型符合设计文档定义
- [ ] 技术选型符合 Phase 0 约束

#### Constitution 合规性（Phase 1）

- [ ] 代码风格遵循 Constitution
- [ ] 类型注解符合 Constitution 标准
- [ ] 架构设计符合 Constitution 原则
- [ ] 命名约定遵循 Constitution
- [ ] 所有技术约束满足

#### Notes

_– Skill: 调用 `python-development:python-pro`_
_– Subject: "实现 {feature} 使测试通过（GREEN phase）"_
_– 自动验证: 所有质量门控通过_

---

### 4.3 REFACTOR Phase (Medium+ Complexity)

#### Completion Status

- [ ] Phase 0 requirements maintained
- [ ] Constitution principles maintained
- [ ] Code refactored
- [ ] Duplication eliminated
- [ ] Code complexity reduced per Constitution standards
- [ ] All tests still pass
- [ ] Coverage maintained or improved
- [ ] Performance improved or maintained
- [ ] Type annotations remain complete
- [ ] Refactoring preserves Phase 0 design intent

#### Verification Results

```bash
# Post-refactor tests
pytest tests/ -v --tb=short

Result: {passed_count} / {total_count} tests still pass ✅

# Coverage comparison
Before: {coverage_before}%
After:  {coverage_after}%
Change: {coverage_delta}%

# Refactoring improvements
- {improvement_1}
- {improvement_2}
- {improvement_3}

# Quality gates maintained
ruff check src/: ✅ PASS
mypy src/: ✅ PASS
```

#### 需求合规性（Phase 0）

- [ ] 重构未改变 Phase 0 需求
- [ ] 功能行为仍然符合设计文档
- [ ] API 接口仍然符合规格
- [ ] 数据模型保持一致

#### Constitution 合规性（Phase 1）

- [ ] 重构未违反 Constitution 原则
- [ ] 代码复杂度符合 Constitution 标准
- [ ] 类型注解仍然完整
- [ ] 架构设计仍然符合 Constitution

#### Notes

_– Skill: 调用 `python-development:python-pro`_
_– Subject: "重构 {feature} 实现代码（REFACTOR phase）"_
_– 重构目标: {refactoring_goals}_
_– 自动验证: 测试保持通过，代码质量提升_

---

## Phase 5: 质量审核 + Git 完成

### 5.1 Quality Gates

#### 需求合规性验证（Phase 0）

- [ ] 所有 Phase 0 功能需求已实现
- [ ] API 端点符合设计文档规格
- [ ] 数据模型符合设计文档定义
- [ ] 行为符合需求规格
- [ ] 无需求遗漏

#### Constitution 合规性验证（Phase 1）

- [ ] 所有编码标准检查通过
- [ ] 所有架构原则检查通过
- [ ] 所有技术约束检查通过
- [ ] 所有自定义原则检查通过
- [ ] 无违反 Constitution 的代码

#### Completion Status

#### Simple Projects (80%+ coverage)

- [ ] All tests pass (100%)
- [ ] Coverage meets minimum (80%+)
- [ ] Code style checks pass (ruff)
- [ ] Application starts successfully

#### Medium Projects (90%+ coverage)

- [ ] All tests pass (100%)
- [ ] Coverage meets minimum (90%+)
- [ ] Code style checks pass (ruff)
- [ ] Type checking passes (mypy)
- [ ] Application starts successfully

#### Complex Projects (95%+ coverage)

- [ ] All tests pass (100%)
- [ ] Coverage meets minimum (95%+)
- [ ] Code style checks pass (ruff)
- [ ] Strict type checking passes (mypy --strict)
- [ ] Application starts successfully
- [ ] Security scan passes (if applicable)
- [ ] Performance benchmarks met (if applicable)

#### Final Verification Results

```bash
# Final test run
pytest tests/ -v

Result: {passed_count} / {total_count} tests passed ✅

# Final coverage
pytest --cov=src --cov-report=term-missing

Coverage: {final_coverage}% (threshold: {threshold}%) ✅

# Code style
ruff check src/

Checked {checked_files} files
Found {ruff_errors} errors, {ruff_warnings} warnings

# Type checking
mypy {mypy_args} src/

Found {mypy_errors} errors

# Application startup
python -c "from {package_name} import app; print('✅ App starts successfully')"

Output: ✅ App imports successfully
```

---

### 5.2 Git Completion

#### Completion Status

- [ ] All changes committed
- [ ] Commit messages follow conventions
- [ ] CHECKLIST.md committed
- [ ] Ready for PR/merge (if applicable)

#### Git History

```
{git_log_output}
```

#### Final Commit

```
{final_commit_details}
```

---

## User Final Review

### Summary

- **Total Phases**: 5 (Phase 0, 1, 2, 4, 5)
- **Completion Status**: {completed_phases} / 5 phases complete
- **Total Tests**: {total_tests}
- **Final Coverage**: {final_coverage}%
- **Quality Gates**: ✅ All Pass / ⚠️ Some Warnings / ❌ Failed

### Issues Found

- [ ] None
- [ ] Issue 1: _______________
- [ ] Issue 2: _______________
- [ ] Issue 3: _______________

### Recommendations

- {recommendation_1}
- {recommendation_2}
- {recommendation_3}

### Next Steps (if any)

- [ ] Project complete, ready for production
- [ ] Additional features needed: _______________
- [ ] Documentation updates needed: _______________
- [ ] Performance improvements needed: _______________

---

## User Sign-off

### Review Checklist

- [ ] I have reviewed the CHECKLIST.md
- [ ] All phases are complete
- [ ] All quality gates have passed
- [ ] Issues have been addressed
- [ ] I approve this project for {production / next phase}

### Approval

**User Name**: _______________
**Date**: _______________
**Status**: ✅ Approved / ⚠️ Approved with reservations / ❌ Needs revision

**Comments**:
_______________
_______________

---

**Checklist Version**: 1.0
**Last Updated**: 2026-02-10
**Skill**: language-skill-python
