# 编排者防错指南

## 🎯 核心概念：脚手架 vs 业务编码

**你是编排者（ORCHESTRATOR），负责调用工具和创建脚手架！**

### 📁 脚手架创建（允许使用 Write 工具）

**脚手架 = 项目基础设施配置**

**特征**：
- ✅ 模板化代码（main.py, config.py, router.py）
- ✅ 零业务逻辑
- ✅ 所有项目都需要
- ✅ 可自动化生成

**示例**：
```python
# ✅ 允许：创建脚手架文件
Write("src/project_name/main.py", content="""
from fastapi import FastAPI
app = FastAPI()
""")

Write("src/project_name/config.py", content="""
class Settings(BaseSettings):
    PROJECT_NAME: str
""")

Write("pyproject.toml", content="[project]\nname = 'project-name'")
```

### 🔬 TDD 编码（禁止手动编写）

**业务编码 = 实现具体需求（需要测试驱动）**

**特征**：
- ❌ 包含业务逻辑（产品管理、购物车功能）
- ❌ 需要创造性设计
- ❌ 需要测试验证
- ❌ 必须使用 TDD 工具链

**示例**：
```python
# ❌ 禁止：手动编写业务逻辑
Write("src/products.py", content="""
class ProductService:
    def create_product(self, name, price):
        # 这是业务逻辑，必须用 TDD 工具！
        pass
""")

# ✅ 正确：调用 TDD 工具
Task(subagent_type="unit-testing:test-automator",
     prompt="生成产品管理功能的测试套件")
```

### 🔍 判断标准

| 问题 | 是 → 脚手架 | 否 → 业务编码 |
|------|-----------|------------|
| 1. 是否所有类似项目都需要？ | ✅ | ❌ |
| 2. 是否包含具体业务逻辑？ | ❌ | ✅ |
| 3. 能否用模板自动生成？ | ✅ | ❌ |
| 4. 是否需要测试验证业务需求？ | ❌ | ✅ |

---

## 禁止的行为模式

### 模式 1: 手动编写业务逻辑

❌ **错误示例**：
```python
# 编排者直接编写业务代码
Write("src/products.py", content="""
class ProductService:
    def create_product(self, name: str, price: Decimal):
        # 业务逻辑实现
        product = Product(name=name, price=price)
        return product
""")

Write("tests/test_products.py", content="""
def test_create_product():
    # 测试代码
    assert True
""")
```

**后果**：
- 跳过了 TDD 的 RED phase
- 没有经过测试驱动验证
- 违反了测试驱动开发原则

**正确做法**：
```python
# 调用 TDD 工具链
Task(subagent_type="unit-testing:test-automator",
     prompt="生成产品管理功能的测试套件（RED phase）")

# 等待测试生成后
Task(subagent_type="python-development:python-pro",
     prompt="实现产品管理功能使测试通过（GREEN phase）")
```

### 模式 1.5: 手动创建脚手架（这是允许的！）

✅ **正确示例**：
```python
# 编排者创建脚手架（基础设施配置）
Write("src/project_name/main.py", content="""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title=settings.PROJECT_NAME)
app.add_middleware(CORSMiddleware, ...)
app.include_router(api_router)
""")

Write("src/project_name/config.py", content="""
class Settings(BaseSettings):
    PROJECT_NAME: str
    VERSION: str
""")

Write("pyproject.toml", content="""
[project]
name = "project-name"
dependencies = ["fastapi>=0.110.0", ...]
""")
```

**为什么这是允许的**：
- 这是基础设施配置，不是业务逻辑
- 所有 FastAPI 项目都需要相同的结构
- 可以用模板自动生成
- 不需要测试验证（只是空壳）

---

### 模式 2: "帮工具一把"

❌ **错误示例**：
```
工具正在生成测试，我觉得可以"帮它"实现功能代码
```

**后果**：
- 破坏了工具的完整性
- 可能产生不一致的代码
- 失去了工具的验证机制

**正确做法**：
```
等待工具完整返回，然后验证结果
```

---

### 模式 3: 跳过工具调用

❌ **错误示例**：
```
Phase 2 完成脚手架后，直接进入 Phase 5
（跳过了 Phase 4 的 TDD 工具）
```

**后果**：
- 没有 TDD 保证代码质量
- 没有自动化测试
- 违反了核心流程

**正确做法**：
```
Phase 2 → Phase 3 → Phase 4（调用 TDD 工具）→ Phase 5
```

---

### 模式 4: "简单项目不需要工具"

❌ **错误示例**：
```
这是简单项目，我自己快速写完就行
```

**后果**：
- 简单项目也需要质量保证
- 失去了标准化的流程
- 可能产生技术债

**正确做法**：
```
所有项目都应该使用工具，只是工具选择不同
```

---

## 自检清单

在执行任何操作前，问自己：

### 问题 1: 我在做什么？
- [ ] 我在创建脚手架（基础设施）✅ → 可以使用 Write 工具
- [ ] 我在调用工具（Skill/Task/Bash）✅ → 正确
- [ ] 我在编写业务逻辑代码 ❌ → **立即停止！使用 TDD 工具**

### 问题 2: 我使用了什么工具？
- [ ] Skill 工具（调用 TDD 工具链）✅
- [ ] Task 工具（调用专业 agent）✅
- [ ] Bash 工具（创建目录、安装依赖）✅
- [ ] Write 工具（创建脚手架模板）✅
- [ ] Write 工具（编写业务代码）❌ → **立即停止！**

### 问题 3: 这是脚手架还是业务编码？
**使用判断标准**：
- [ ] 所有项目都需要这个文件？ ✅ → 脚手架
- [ ] 包含具体业务逻辑？ ✅ → 业务编码（使用工具）
- [ ] 可以用模板自动生成？ ✅ → 脚手架
- [ ] 需要测试验证业务需求？ ✅ → 业务编码（使用工具）

---

## 常见错误信号

| 信号 | 说明 | 判断 | 正确做法 |
|------|------|------|---------|
| 你正在用 Write 创建 main.py | 脚手架模板 | ✅ 允许 | 继续 |
| 你正在用 Write 创建 config.py | 脚手架模板 | ✅ 允许 | 继续 |
| 你正在用 Write 创建 pyproject.toml | 配置文件 | ✅ 允许 | 继续 |
| 你正在用 Write 创建 products.py | 业务逻辑 | ❌ 禁止 | 停止！调用 TDD 工具 |
| 你正在用 Write 创建 test_xxx.py | 测试代码 | ❌ 禁止 | 停止！调用 test-automator |
| 你在想"我可以快速写完" | 业务逻辑 | ❌ 禁止 | 停止！工具更快更可靠 |
| 你在"帮工具加速" | 任何代码 | ❌ 禁止 | 停止！等待工具返回 |

---

## 紧急恢复程序

如果你发现自己正在自行编码：

1. **🛑 立即停止**所有编码操作

2. **🗑️ 删除**手动创建的文件
   ```bash
   rm -rf src/ tests/  # 删除手动创建的代码
   ```

3. **🤔 重新思考**
   - 我应该调用哪个工具？
   - 工具的参数是什么？

4. **🔧 调用工具**
   ```python
   Skill(skill="python-project-tdd", args="...")
   ```

5. **⏸️ 等待**工具完成

6. **✅ 验证**工具输出

---

## 记住

> **"脚手架 ≠ 业务编码"**

- 脚手架：配置项目基础设施 → 可以使用 Write 工具
- 业务编码：实现具体需求 → 必须使用 TDD 工具链

> **"工具比手动更强大、更快速、更可靠"**

- 工具会自动生成完整的测试
- 工具会自动运行质量检查
- 工具会确保 TDD 流程正确
- 工具会比你手动快 10 倍（根据测试数据）

**不要混淆脚手架和业务编码！让工具完成业务逻辑实现！**

---

**文档版本**: 2.0.0
**更新时间**: 2026-02-09
**用途**: 阐明脚手架创建与 TDD 编码的区别
**变更内容**:
- v2.0.0: 明确脚手架可以使用 Write 工具，业务编码必须使用 TDD 工具
- v1.0.0: 初始版本（"禁止自行编码"表述过于模糊）
