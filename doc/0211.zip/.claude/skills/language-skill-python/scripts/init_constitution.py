#!/usr/bin/env python3
"""
Initialize constitution template for new projects.

This script creates the .specify/memory/constitution.md template file
if it doesn't exist. This is called before invoking speckit.constitution skill.
"""

import sys
from pathlib import Path


def create_constitution_template(project_path: Path, project_name: str, project_type: str) -> Path:
    """
    Create a constitution template file.

    Args:
        project_path: Path to the project root
        project_name: Name of the project
        project_type: Type of project (fastapi, cli, data, generic)

    Returns:
        Path to the created constitution file
    """
    specify_dir = project_path / ".specify" / "memory"
    specify_dir.mkdir(parents=True, exist_ok=True)

    constitution_path = specify_dir / "constitution.md"

    # Only create if doesn't exist
    if constitution_path.exists():
        return constitution_path

    # Template content
    template = f"""# Project Constitution

## Version Information
- **Version**: 1.0.0
- **Ratification Date**: {Path.cwd().name}
- **Last Amended Date**: TBD

---

## Project Overview

**Project Name**: {project_name}
**Project Type**: {project_type}
**Description**: Project description to be filled

---

## Principle 1: Technology Stack Constraints

### Python Version
- **MUST** use Python >= 3.12
- **MUST** leverage modern Python features (type hints, pattern matching, etc.)

### Core Dependencies
- **MUST** specify framework dependencies
- **SHOULD** use well-maintained libraries

**Rationale**: Modern Python with type safety ensures maintainability.

---

## Principle 2: Code Quality Standards

### Type Safety
- **MUST** use type annotations for all public functions
- **MUST** pass mypy type checking
- **SHOULD** use type hints for internal functions where non-obvious

### Code Style
- **MUST** use ruff for formatting and linting
- **MUST** follow PEP 8 style guide

### Documentation
- **MUST** provide docstrings for all public functions

**Rationale**: Type safety and consistent style reduce bugs.

---

## Principle 3: Testing Discipline

### Test Coverage
- **MUST** maintain test coverage >= 80%
- **MUST** write tests before implementation (TDD approach)

### Test Framework
- **MUST** use pytest for testing
- **SHOULD** use pytest fixtures for test data

### Quality Gates
- **MUST** run pytest before commits
- **MUST** fix all failing tests before proceeding

**Rationale**: High test coverage and TDD ensure reliability.

---

## Principle 4: Architecture Principles

### Simplicity First
- **MUST** keep architecture appropriate for project size
- **MUST** follow single responsibility principle

### Error Handling
- **MUST** provide clear error messages
- **MUST** handle errors gracefully

**Rationale**: Simple, robust design ensures maintainability.

---

## Principle 5: Development Workflow

### Git Workflow
- **MUST** use feature branches for development
- **MUST** write meaningful commit messages

### Code Review
- **MUST** undergo code review before merging

**Rationale**: Structured workflow maintains code quality.

---

## Governance

### Amendment Procedure
1. Propose changes via pull request
2. Discuss and refine with team
3. Update version number
4. Update LAST_AMENDED_DATE

---

**Created**: Auto-generated template
**Purpose**: Project constitution for {project_name}
**Note**: Update this template with project-specific rules
"""

    constitution_path.write_text(template, encoding="utf-8")
    return constitution_path


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: init_constitution.py <project_path> <project_name> [project_type]")
        print("Example: init_constitution.py /path/to/project my-project cli")
        sys.exit(1)

    project_path = Path(sys.argv[1])
    project_name = sys.argv[2]
    project_type = sys.argv[3] if len(sys.argv) > 3 else "generic"

    result = create_constitution_template(project_path, project_name, project_type)
    print(f"Constitution template created: {result}")
